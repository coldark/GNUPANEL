<?php
/*
  $Id: account_newsletters.php,v 1.2 2003/07/11 09:04:22 jan0815 Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Ihr Konto');
define('NAVBAR_TITLE_2', 'Newsletter Abonnements');

define('HEADING_TITLE', 'Newsletter Abonnements');

define('MY_NEWSLETTERS_TITLE', 'Meine Newsletter Abonnements');
define('MY_NEWSLETTERS_GENERAL_NEWSLETTER', 'Allgmeiner Newsletter');
define('MY_NEWSLETTERS_GENERAL_NEWSLETTER_DESCRIPTION', 'Beinhaltet allgemeine Nachrichten &uuml;nseren Shop, Informationen &uuml;ber neue Produkte, Sonderangebote und andere Informationen von allgemeinem Interesse.');

define('SUCCESS_NEWSLETTER_UPDATED', 'Ihre Newsletter Abonnements wurden erfolgreich aktualisiert!');
?>
