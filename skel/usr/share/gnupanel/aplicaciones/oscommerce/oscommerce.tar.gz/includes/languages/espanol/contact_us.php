<?php
/*
  $Id: contact_us.php,v 1.7 2003/07/08 16:45:36 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Contactenos');
define('NAVBAR_TITLE', 'Contactenos');
define('TEXT_SUCCESS', 'Su consulta ha sido enviada al encargado de la tienda.');
define('EMAIL_SUBJECT', 'Consulta desde ' . STORE_NAME);

define('ENTRY_NAME', 'Nombre Completo:');
define('ENTRY_EMAIL', 'Direcci&oacute;n E-Mail:');
define('ENTRY_ENQUIRY', 'Consulta:');
?>