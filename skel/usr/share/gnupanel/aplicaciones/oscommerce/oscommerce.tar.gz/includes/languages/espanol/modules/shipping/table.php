<?php
/*
  $Id: table.php,v 1.5 2002/11/19 01:14:34 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_TABLE_TEXT_TITLE', 'Tabla de Tarifas');
define('MODULE_SHIPPING_TABLE_TEXT_DESCRIPTION', 'Tabla de Tarifas');
define('MODULE_SHIPPING_TABLE_TEXT_WAY', '');
define('MODULE_SHIPPING_TABLE_TEXT_WEIGHT', 'Peso');
define('MODULE_SHIPPING_TABLE_TEXT_AMOUNT', 'Total');
?>
