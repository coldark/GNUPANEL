<?php
// $Id: xoopsuser.php 2 2005-11-02 18:23:29Z skalpa $
// this file is for backward compatibility only
if (!defined('XOOPS_ROOT_PATH')) {
	exit();
}
require_once XOOPS_ROOT_PATH.'/kernel/user.php';
?>