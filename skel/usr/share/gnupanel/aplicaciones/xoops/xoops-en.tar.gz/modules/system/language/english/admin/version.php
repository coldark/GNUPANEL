<?php
// $Id: version.php 2 2005-11-02 18:23:29Z skalpa $
//%%%%%%	Admin Module Name  Version 	%%%%%
define("_AM_DBUPDATED",_MD_AM_DBUPDATED);


?>