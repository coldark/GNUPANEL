<?php
// $Id: admin.php 890 2007-07-28 09:26:05Z phppp $
//%%%%%%	File Name  admin.php 	%%%%%
define('_MD_AM_DBUPDATED','Database Updated Successfully!');

define('_MD_AM_CONFIG','System Configuration');


// Admin Module Names
define('_MD_AM_ADGS','Groups');
define('_MD_AM_BANS','Banners');
define('_MD_AM_BKAD','Blocks');
define('_MD_AM_MDAD','Modules');
define('_MD_AM_SMLS','Smilies');
define('_MD_AM_RANK','User Ranks');
define('_MD_AM_USER','Edit Users');
define('_MD_AM_FINDUSER', 'Find Users');
define('_MD_AM_PREF','Preferences');
define('_MD_AM_VRSN','Version');
define('_MD_AM_MLUS', 'Mail Users');
define('_MD_AM_IMAGES', 'Image Manager');
define('_MD_AM_AVATARS', 'Avatars');
define('_MD_AM_TPLSETS', 'Templates');
define('_MD_AM_COMMENTS', 'Comments');

// Group permission phrases
define('_MD_AM_PERMADDNG', 'Could not add %s permission to %s for group %s');
define('_MD_AM_PERMADDOK','Added %s permission to %s for group %s');
define('_MD_AM_PERMRESETNG','Could not reset group permission for module %s');
define('_MD_AM_PERMADDNGP', 'All parent items must be selected.');
?>