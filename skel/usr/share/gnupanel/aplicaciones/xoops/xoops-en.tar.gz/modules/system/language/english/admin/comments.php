<?php
// $Id: comments.php 2 2005-11-02 18:23:29Z skalpa $
//%%%%%% Comment Manager %%%%%
define('_MD_AM_COMMMAN','Comment Manager');

define('_MD_AM_LISTCOMM','List Comments');
define('_MD_AM_ALLMODS','All modules');
define('_MD_AM_ALLSTATUS','Any status');
define('_MD_AM_MODULE','Module');
define('_MD_AM_COMFOUND','%s comment(s) found.');
?>