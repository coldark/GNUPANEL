<?php
// $Id: findusers.php 839 2007-06-28 20:05:30Z malanciault $
//%%%%%%	File Name findusers.php 	%%%%%

define("_AM_FINDUS","Find Users");
define("_AM_AVATAR","Avatar");
define("_AM_REALNAME","Real Name");
define("_AM_REGDATE","Joined Date");
define("_AM_EMAIL","Email");
define("_AM_PM","PM");
define("_AM_URL","URL");
define("_AM_PREVIOUS","Previous");
define("_AM_NEXT","Next");
define("_AM_USERSFOUND","%s user(s) found");

define("_AM_ACTUS", "Active Users: %s");
define("_AM_INACTUS", "Inactive Users: %s");
define("_AM_NOFOUND","No Users Found");
define("_AM_UNAME","User Name");
define("_AM_ICQ","ICQ Number");
define("_AM_AIM","AIM Handle");
define("_AM_YIM","YIM Handle");
define("_AM_MSNM","MSNM Handle");
define("_AM_LOCATION","Location contains");
define("_AM_OCCUPATION","Occupation contains");
define("_AM_INTEREST","Interest contains");
define("_AM_URLC","URL contains");
define("_AM_LASTLOGMORE","Last login is more than <span style='color:#ff0000;'>X</span> days ago");
define("_AM_LASTLOGLESS","Last login is less than <span style='color:#ff0000;'>X</span> days ago");
define("_AM_REGMORE","Joined date is more than <span style='color:#ff0000;'>X</span> days ago");
define("_AM_REGLESS","Joined date is less than <span style='color:#ff0000;'>X</span> days ago");
define("_AM_POSTSMORE","Number of Posts is greater than <span style='color:#ff0000;'>X</span>");
define("_AM_POSTSLESS","Number of Posts is less than <span style='color:#ff0000;'>X</span>");
define("_AM_SORT","Sort by");
define("_AM_ORDER","Order");
define("_AM_LASTLOGIN","Last login");
define("_AM_POSTS","Number of posts");
define("_AM_ASC","Ascending order");
define("_AM_DESC","Descending order");
define("_AM_LIMIT","Number of users per page");
define("_AM_RESULTS", "Search results");
define("_AM_SHOWMAILOK", "Type of users to show");
define("_AM_MAILOK","Only users that accept mail");
define("_AM_MAILNG","Only users that don't accept mail");
define("_AM_SHOWTYPE", "Type of users to show");
define("_AM_ACTIVE","Only active users");
define("_AM_INACTIVE","Only inactive users");
define("_AM_BOTH", "All users");
define("_AM_SENDMAIL", "Send mail");
define("_AM_ADD2GROUP", "Add users to %s group");

define("_AM_GROUPS", "Groups");
?>