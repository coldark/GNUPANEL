<?php
// $Id: banners.php 2 2005-11-02 18:23:29Z skalpa $
//%%%%%%        Admin Module Name  Banners         %%%%%
define("_AM_DBUPDATED",_MD_AM_DBUPDATED);

define("_AM_CURACTBNR","Current Active Banners");
define("_AM_BANNERID","Banner ID");
define("_AM_IMPRESION","Impressions");
define("_AM_IMPLEFT","Imp. Left");
define("_AM_CLICKS","Clicks");
define("_AM_NCLICKS","% Clicks");
define("_AM_CLINAME","Client Name");
define("_AM_FUNCTION","Functions");
define("_AM_UNLIMIT","Unlimited");
define("_AM_EDIT","Edit");
define("_AM_DELETE","Delete");
define("_AM_FINISHBNR","Finished Banners");
define("_AM_IMPD","Imp.");
define("_AM_STARTDATE","Date Started");
define("_AM_ENDDATE","Date Ended");
define("_AM_ADVCLI","Advertising Clients");
define("_AM_ACTIVEBNR","Active Banners");
define("_AM_CONTNAME","Contact Name");
define("_AM_CONTMAIL","Contact Email");
define("_AM_CLINAMET","Client Name:");
define("_AM_ADDNWBNR","Add a New Banner");
define("_AM_IMPPURCHT","Impressions Purchased:");
define("_AM_IMGURLT","Image URL:");
define("_AM_CLICKURLT","Click URL:");
define("_AM_ADDBNR","Add Banner");
define("_AM_ADDNWCLI","Add a New Client");
define("_AM_CONTNAMET","Contact Name:");
define("_AM_CONTMAILT","Contact Email:");
define("_AM_CLILOGINT","Client Login:");
define("_AM_CLIPASST","Client Password:");
define("_AM_ADDCLI","Add Client");
define("_AM_DELEBNR","Delete Banner");
define("_AM_SUREDELE","Are you sure you want to delete this Banner?");
define("_AM_NO","No");
define("_AM_YES","Yes");
define("_AM_EDITBNR","Edit Banner");
define("_AM_ADDIMPT","Add More Impressions:");
define("_AM_PURCHT","Purchased:");
define("_AM_MADET","Made:");
define("_AM_CHGBNR","Change Banner");
define("_AM_DELEADC","Delete Advertising Client");
define("_AM_SUREDELCLI","You are about to delete client <b>%s</b> and all its Banners!!!");
define("_AM_NOBNRRUN","This client doesn't have any banner running now.");
define("_AM_WARNING","WARNING!!!");
define("_AM_ACTBNRRUN","This client has the following ACTIVE BANNERS running on our site:");
define("_AM_SUREDELBNR","Are you sure you want to delete this Client and ALL its Banners?");
define("_AM_EDITADVCLI","Edit Advertising Client");
define("_AM_EXTINFO","Extra Info:");
define("_AM_CHGCLI","Change Client");
define("_AM_USEHTML","Use Html?");
define("_AM_CODEHTML","Code Html:");

?>