<?php
// $Id: version.php 1074 2007-10-11 15:21:11Z phppp $
define("XOOPS_VERSION","XOOPS 2.0.17.1");
?>