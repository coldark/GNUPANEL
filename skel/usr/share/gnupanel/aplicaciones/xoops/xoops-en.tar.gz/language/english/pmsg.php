<?php
// $Id: pmsg.php 2 2005-11-02 18:23:29Z skalpa $
//%%%%%%	File Name readpmsg.php 	%%%%%
define("_PM_DELETED","Your message(s) has been deleted");
define("_PM_PRIVATEMESSAGE","Private Messages");
define("_PM_INBOX","Inbox");
define("_PM_FROM","From");
define("_PM_YOUDONTHAVE","You don't have any private messages");
define("_PM_FROMC","From: ");
define("_PM_SENTC","Sent: "); // The date of message sent
define("_PM_PROFILE","Profile");

// %s is a username
define("_PM_PREVIOUS","Previous Message");
define("_PM_NEXT","Next Message");

//%%%%%%	File Name pmlite.php 	%%%%%
define("_PM_SORRY","Sorry! You are not a registered user.");
define("_PM_REGISTERNOW","Register Now!");
define("_PM_GOBACK","Go Back");
define("_PM_USERNOEXIST","The selected user doesn't exist in the database.");
define("_PM_PLZTRYAGAIN","Please check the name and try again.");
define("_PM_MESSAGEPOSTED","Your message has been posted");
define("_PM_CLICKHERE","You can click here to view your private messages");
define("_PM_ORCLOSEWINDOW","Or click here to close this window.");
define("_PM_USERWROTE","%s wrote:");
define("_PM_TO","To: ");
define("_PM_SUBJECTC","Subject: ");
define("_PM_MESSAGEC","Message: ");
define("_PM_CLEAR","Clear");
define("_PM_CANCELSEND","Cancel Send");
define("_PM_SUBMIT","Submit");

//%%%%%%	File Name viewpmsg.php 	%%%%%
define("_PM_SUBJECT","Subject");
define("_PM_DATE","Date");
define("_PM_NOTREAD","Not Read");
define("_PM_SEND","Send");
define("_PM_DELETE","Delete");
define("_PM_REPLY", "Reply");
define("_PM_PLZREG","Please register first to send private messages!");

define("_PM_ONLINE", "Online");
?>