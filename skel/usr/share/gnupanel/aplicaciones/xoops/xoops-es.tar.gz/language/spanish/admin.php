<?php // Xoops Spanish Support (http://www.esxoops.com)
// $Id: admin.php 2 2005-11-02 18:23:29Z skalpa $
//%%%%%%	File Name  admin.php 	%%%%%
define('_AD_NORIGHT','Disculpe. No tiene permiso para acceder a esta zona.');
define('_AD_ACTION','Acci�n');
define('_AD_EDIT','Editar');
define('_AD_DELETE','Borrar');
define('_AD_LASTTENUSERS','�ltimos 10 usuarios registrados');
define('_AD_NICKNAME','Apodo');
define('_AD_EMAIL','Correo');
define('_AD_AVATAR','Avatar');
define('_AD_REGISTERED','Registrado');
define('_AD_PRESSGEN', 'Luego de cambiar las preferencias se reconstruir�n algunos par�metros. <br />Haga clic para continuar.');
define('_AD_LOGINADMIN', 'Conectando...');
?>