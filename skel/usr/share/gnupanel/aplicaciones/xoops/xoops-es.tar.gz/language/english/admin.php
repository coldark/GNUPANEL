<?php
// $Id: admin.php 2 2005-11-02 18:23:29Z skalpa $
//%%%%%%	File Name  admin.php 	%%%%%
define("_AD_NORIGHT","You don't have the right to access this area");
define("_AD_ACTION","Action");
define("_AD_EDIT","Edit");
define("_AD_DELETE","Delete");
define("_AD_LASTTENUSERS","Last 10 registered users");
define("_AD_NICKNAME","Nickname");
define("_AD_EMAIL","Email");
define("_AD_AVATAR","Avatar");
define("_AD_REGISTERED","Registered"); //Registered Date
define('_AD_PRESSGEN', 'This is your first time to enter the administration section. Press the button below to proceed.');
define('_AD_LOGINADMIN', 'Logging you in..');
?>