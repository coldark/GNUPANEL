<?php
// $Id: notification.php 2 2005-11-02 18:23:29Z skalpa $

// RMV-NOTIFY

// Text for various templates...

define ('_NOT_NOTIFICATIONOPTIONS', 'Opciones de Notificaci�n ');
define ('_NOT_UPDATENOW', 'Actualizar');
define ('_NOT_UPDATEOPTIONS', 'Actualizar Opciones de Notificaci�n');

define ('_NOT_CLEAR', 'Limpiar');
define ('_NOT_CHECKALL', 'Marcar Todo');
define ('_NOT_MODULE', 'M�dulo');
define ('_NOT_CATEGORY', 'Categor�a');
define ('_NOT_ITEMID', 'ID');
define ('_NOT_ITEMNAME', 'Nombre');
define ('_NOT_EVENT', 'Evento');
define ('_NOT_EVENTS', 'Eventos');
define ('_NOT_ACTIVENOTIFICATIONS', 'Activar Notificaciones');
define ('_NOT_NAMENOTAVAILABLE', 'Nombre No Disponible');
// RMV-NEW : TODO: remove NAMENOTAVAILBLE above
define ('_NOT_ITEMNAMENOTAVAILABLE', 'Nombre NO disponible');
define ('_NOT_ITEMTYPENOTAVAILABLE', 'Tipo No disponible');
define ('_NOT_ITEMURLNOTAVAILABLE', 'URL No disponible');
define ('_NOT_DELETINGNOTIFICATIONS', 'Borrando Notificaciones');
define ('_NOT_DELETESUCCESS', 'Notificaci�n(es) borrada(s) satisfactoriamente.');
define ('_NOT_UPDATEOK', 'Opciones de notificaci�n actualizadas');
define ('_NOT_NOTIFICATIONMETHODIS', 'M�todo de Notificaci�n ');
define ('_NOT_EMAIL', 'Correo');
define ('_NOT_PM', 'Mensaje Pivado');
define ('_NOT_DISABLE', 'Deshabilitado');
define ('_NOT_CHANGE', 'Cambiar');

define ('_NOT_NOACCESS', 'No tiene permiso para acceder a esta p�gina.');

// Text for module config options

define ('_NOT_ENABLE', 'Habilitar');
define ('_NOT_NOTIFICATION', 'Notificaci�n');

define ('_NOT_CONFIG_ENABLED', 'Activar Notificaci�n');
define ('_NOT_CONFIG_ENABLEDDSC', 'Este m�dulo permitir� recibir notificaci�n de eventos espec�ficos sucedidos.  Elija "S�" para activarlo.');

define ('_NOT_CONFIG_EVENTS', 'Activar Eventos Espec�ficos');
define ('_NOT_CONFIG_EVENTSDSC', 'Determine los eventos a los que podr� suscribirse el usuario.');

define ('_NOT_CONFIG_ENABLE', 'Activar Notificaci�n');
define ('_NOT_CONFIG_ENABLEDSC', 'Este m�dulo permitir� recibir notificaci�n de cuando un evento espec�fico ha ocurrido. Determine si los usuarios deber�an ser notificados en un Bloque, en el M�dulo o en Ambos. Para que la notificaci�n del Bloque sea operativa, previamente deber�a haber activado dicho bloque.');
define ('_NOT_CONFIG_DISABLE', 'Desactivar Notificaci�n');
define ('_NOT_CONFIG_ENABLEBLOCK', 'Activar en BLOQUE');
define ('_NOT_CONFIG_ENABLEINLINE', 'Activar en M�DULO');
define ('_NOT_CONFIG_ENABLEBOTH', 'Activar en BLOQUE-M�DULO');

// For notification about comment events

define ('_NOT_COMMENT_NOTIFY', 'Comentario Agregado');
define ('_NOT_COMMENT_NOTIFYCAP', 'Recibir notificaci�n cuando un nuevo comentario sea escrito.');
define ('_NOT_COMMENT_NOTIFYDSC', 'Recibir notificaci�n cuando un nuevo comentario sea escrito o aprobado.');
define ('_NOT_COMMENT_NOTIFYSBJ', '[{X_SITENAME}] {X_MODULE} auto-notificaci�n : Comentario agregado a {X_ITEM_TYPE}');

define ('_NOT_COMMENTSUBMIT_NOTIFY', 'Comentario Enviado');
define ('_NOT_COMMENTSUBMIT_NOTIFYCAP', 'Recibir notificaci�n cuando un nuevo comentario sea enviado(aguardando aprobaci�n).');
define ('_NOT_COMMENTSUBMIT_NOTIFYDSC', 'Receibir notificaci�n cuando un nuevo comentario sea enviado(aguardando aprobaci�n).');
define ('_NOT_COMMENTSUBMIT_NOTIFYSBJ', '[{X_SITENAME}] {X_MODULE} auto-notificaci�n : Comentario enviado para {X_ITEM_TYPE}');

// For notification bookmark feature
// (Not really notification, but easy to do with this module)

define ('_NOT_BOOKMARK_NOTIFY', 'Agenda');
define ('_NOT_BOOKMARK_NOTIFYCAP', 'Agendar este elemento (sin notificaci�n)');
define ('_NOT_BOOKMARK_NOTIFYDSC', 'Mantener un seguimiento de este elemento sin recibir ninguna notificaci�n al respecto.');

// For user profile
// FIXME: These should be reworded a little...

define ('_NOT_NOTIFYMETHOD', 'M�todo de Notificaci�n: �de qu� manera desea recibir la notificaci�n cuando realice un seguimiento? (por ejemplo de un foro)');
define ('_NOT_METHOD_EMAIL', 'Correo (usar email de mi perfil)');
define ('_NOT_METHOD_PM', 'Mensaje Privado');
define ('_NOT_METHOD_DISABLE', 'Deshabilitado moment�neamente');

define ('_NOT_NOTIFYMODE', 'Modo de Notificaci�n por defecto');
define ('_NOT_MODE_SENDALWAYS', 'Recibir Notificaci�n de todas las actualizaciones seleccionadas');
define ('_NOT_MODE_SENDONCE', 'Ser notificado solamente una vez');
define ('_NOT_MODE_SENDONCEPERLOGIN', 'Notific�rmelo una vez y no volver a hacerlo hasta mi pr�ximo ingreso');
?>