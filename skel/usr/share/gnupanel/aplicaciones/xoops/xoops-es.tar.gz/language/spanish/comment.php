<?php
// $Id: comment.php 507 2006-05-26 23:39:35Z skalpa $
define('_CM_TITLE','T�tulo');
define('_CM_MESSAGE','Mensaje');
define('_CM_DOSMILEY','Habilitar Caritas');
define('_CM_DOHTML','Habilitar c�digo HTML');
define('_CM_DOAUTOWRAP','Auto wrap lines');
define('_CM_DOXCODE','Habilitar C�digos XOOPS');
define('_CM_REFRESH','Actualizar');
define('_CM_PENDING','Pendiente');
define('_CM_HIDDEN','Oculto');
define('_CM_ACTIVE','Activo');
define('_CM_STATUS','Estado');
define('_CM_POSTCOMMENT','Enviar Comentario');
define('_CM_REPLIES','Respuestas');
define('_CM_PARENT','Ra�z');
define('_CM_TOP','Encima');
define('_CM_BOTTOM','Debajo');
define('_CM_ONLINE',"&iexcl;En L�nea!");
define('_CM_POSTED','Enviado'); // Posted date
define('_CM_UPDATED', 'Actualizado');
define('_CM_THREAD','Hilo');
define('_CM_POSTER','Autor');
define('_CM_JOINED','Conectado');
define('_CM_POSTS','Env�os');
define('_CM_FROM','Desde');
define('_CM_COMDELETED', 'Comentario(s) Borrado(s).');
define('_CM_COMDELETENG', 'No fue posible borrar el comentario.');
define('_CM_DELETESELECT' , '�Borrar todos los comentarios relacionados?');
define('_CM_DELETEONE' , 'No, Borrar s�lo este comentario');
define('_CM_DELETEALL', 'S�, Borrarlos todos');
define('_CM_THANKSPOST', 'Gracias por el Env�o');
define('_CM_NOTICE', "Los usuarios son responsables de sus propios comentarios.");
define('_CM_COMRULES','Reglas para los comentarios');
define('_CM_COMAPPROVEALL','Los comentarios ser�n siempre aprobados');
define('_CM_COMAPPROVEUSER','Los comentarios de los usuarios registrados ser�n siempre aprobados');
define('_CM_COMAPPROVEADMIN','Todos los comentarios necesitan ser aprobados por el administrador');
define('_CM_COMANONPOST','�Permitir a los usuarios an�nimos enviar comentarios?');
define('_CM_COMNOCOM','Deshabilitar comentarios');
define('_CM_RE','Re');
?>