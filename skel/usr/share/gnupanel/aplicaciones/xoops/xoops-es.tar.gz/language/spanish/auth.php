<?php
// $Id: $
//%%%%%%		File Name auth.php 		%%%%%

define('_AUTH_MSG_AUTH_METHOD',"utilizando el m�todo de autentificaci�n %s");
define('_AUTH_LDAP_EXTENSION_NOT_LOAD','Extensi�n PHP LDAP no cargada (compruebe su configuraci�n PHP revisando el archivo php.ini)');
define('_AUTH_LDAP_SERVER_NOT_FOUND',"Imposible conectar al servidor");
define('_AUTH_LDAP_USER_NOT_FOUND',"Usuario %s no encontrado en el servidor de directorio (%s) en %s");
define('_AUTH_LDAP_CANT_READ_ENTRY',"Imposible leer la entrada %s");
define('_AUTH_LDAP_XOOPS_USER_NOTFOUND',"Lo lamento, no se encontr� informaci�n relativa al usuario en la base de datos para la conexi�n: %s <br>" .
		"Por favor, compruebe sus datos o int�ntelo con el aprovisionamiento autom�tico");
define('_AUTH_LDAP_START_TLS_FAILED',"fall� la conexi�n TLS");
		
?>