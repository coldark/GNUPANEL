<?php // Xoops Spanish Support (http://www.esxoops.com)
// $Id: pmsg.php,v 1.6 2003/02/16 00:50:09 w4z004 Exp $
//%%%%%%	File Name readpmsg.php 	%%%%%
define('_PM_DELETED','Su mensaje fue Borrado.');
define('_PM_PRIVATEMESSAGE','Mensaje Privado');
define('_PM_INBOX','Bandeja de entrada');
define('_PM_FROM','Desde');
define('_PM_YOUDONTHAVE','No tiene ning�n mensaje Privado.');
define('_PM_FROMC','Desde: ');
define('_PM_SENTC','Enviado: ');
define('_PM_PROFILE','Perfil');

// %s is a username
define('_PM_PREVIOUS','Mensaje Anterior');
define('_PM_NEXT','Mensaje Siguiente');

//%%%%%%	File Name pmlite.php 	%%%%%
define('_PM_SORRY','Lo lamento, no Registrado.');
define('_PM_REGISTERNOW','&iexcl;Reg�strese Ahora!');
define('_PM_GOBACK','Volver');
define('_PM_USERNOEXIST','El usuario seleccionado no existe en nuestra base de datos.');
define('_PM_PLZTRYAGAIN','Por favor, revise el nombre e int�ntelo de nuevo.');
define('_PM_MESSAGEPOSTED','Su Mensaje ha sido enviado.');
define('_PM_CLICKHERE','Volver a mis Mensajes Privados');
define('_PM_ORCLOSEWINDOW','Cerrar esta ventana');
define('_PM_USERWROTE','%s Escribi�:');
define('_PM_TO','Para: ');
define('_PM_SUBJECTC','Asunto: ');
define('_PM_MESSAGEC','Mensaje: ');
define('_PM_CLEAR','Limpiar');
define('_PM_CANCELSEND','Cancelar Env�o');
define('_PM_SUBMIT','Enviar');

//%%%%%%	File Name viewpmsg.php 	%%%%%
define('_PM_SUBJECT','Asunto');
define('_PM_DATE','Fecha');
define('_PM_NOTREAD','No Le�do');
define('_PM_SEND','Enviar');
define('_PM_DELETE','Borrar');
define('_PM_PLZREG','Para poder enviar Mensajes Privados tiene que registrarse y/o autentificarse primero.');
define('_PM_REPLY', 'Responder');
define('_PM_ONLINE', 'En L�nea');
?>