<?php // Xoops Spanish Support (http://www.esxoops.com)
// $Id: search.php 2 2005-11-02 18:23:29Z skalpa $
//%%%%%%	File Name search.php 	%%%%%
define('_SR_SEARCH','Buscar');
define('_SR_PLZENTER','&iexcl;Por Favor, cumplimente todos los campos requeridos!');
define('_SR_SEARCHRESULTS','Resultados de la B�squeda');
define('_SR_NOMATCH','No hay registros para su consulta');
define('_SR_FOUND','Se encontraron <b>%s</b> coincidencias');
define('_SR_SHOWING','(Mostrando %d - %d)');
define('_SR_ANY','Cualquiera (or)');
define('_SR_ALL','Todas (and)');
define('_SR_EXACT','Exacta');
define('_SR_SHOWALLR','Mostrar todos los Resultados');
define('_SR_NEXT','Siguiente');
define('_SR_PREVIOUS','Anterior');
define('_SR_KEYWORDS','Palabra(s) clave');
define('_SR_TYPE','Tipo');
define('_SR_SEARCHIN','Buscar en');
define('_SR_KEYTOOSHORT', 'Las palabras clave(keywords) deben contener al menos <b>%s</b> caracteres');
define('_SR_KEYIGNORE', 'Las palabras clave con menos de <b>%s</b> caracteres ser�n ignoradas');
define('_SR_SEARCHRULE', 'Reglas para la B�squeda');
define('_SR_IGNOREDWORDS', 'Las siguientes palabras son demasiado cortas (menos de %u caracteres). No ser�n incluidas en la b�squeda:');
?>