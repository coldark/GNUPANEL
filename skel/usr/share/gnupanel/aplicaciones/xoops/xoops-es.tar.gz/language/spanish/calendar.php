<?php
// $Id: calendar.php 2 2005-11-02 18:23:29Z skalpa $
//%%%%%		Time Zone	%%%%
define("_CAL_SUNDAY", "Domingo");
define("_CAL_MONDAY", "Lunes");
define("_CAL_TUESDAY", "Martes");
define("_CAL_WEDNESDAY", "Mi�rcoles");
define("_CAL_THURSDAY", "Jueves");
define("_CAL_FRIDAY", "Viernes");
define("_CAL_SATURDAY", "S�bado");
define("_CAL_JANUARY", "Enero");
define("_CAL_FEBRUARY", "Febrero");
define("_CAL_MARCH", "Marzo");
define("_CAL_APRIL", "Abril");
define("_CAL_MAY", "Mayo");
define("_CAL_JUNE", "Junio");
define("_CAL_JULY", "Julio");
define("_CAL_AUGUST", "Agosto");
define("_CAL_SEPTEMBER", "Septiembre");
define("_CAL_OCTOBER", "Octubre");
define("_CAL_NOVEMBER", "Noviembre");
define("_CAL_DECEMBER", "Diciembre");
define("_CAL_TGL1STD", "Cambiar primer d�a de la semana");
define("_CAL_PREVYR", "A�o anterior");
define("_CAL_PREVMNTH", "Mes anterior");
define("_CAL_GOTODAY", "Ir Hoy");
define("_CAL_NXTMNTH", "Mes pr�ximo");
define("_CAL_NEXTYR", "A�o pr�ximo");
define("_CAL_SELDATE", "Seleccione la fecha");
define("_CAL_DRAGMOVE", "Arrastre para mover");
define("_CAL_TODAY", "Hoy");
define("_CAL_DISPM1ST", "Mostrar Lunes primero");
define("_CAL_DISPS1ST", "Mostrar Domingo primero");
?>