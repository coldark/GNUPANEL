<?php
// $Id: misc.php 2 2005-11-02 18:23:29Z skalpa $
define("_MSC_YOURNAMEC","Su Nombre: ");
define("_MSC_YOUREMAILC","Su Correo: ");
define("_MSC_FRIENDNAMEC","Nombre de su Amigo: ");
define("_MSC_FRIENDEMAILC","Correo de su Amigo: ");
define("_MSC_RECOMMENDSITE","Recomiende este sitio");
// %s is your site name
define("_MSC_INTSITE","P�gina interesante: %s");
define("_MSC_REFERENCESENT","Su recomendaci�n ha sido enviada al destinatario. &iexcl;Gracias!");
define("_MSC_ENTERYNAME","Por Favor, escriba su nombre");
define("_MSC_ENTERFNAME","Por Favor, especifique el nombre de su amigo");
define("_MSC_ENTERFMAIL","Por Favor, escriba la direcci�n de correo de su amigo");
define("_MSC_NEEDINFO","&iexcl;No ha facilitado toda la informaci�n requerida!");
define("_MSC_INVALIDEMAIL1","La direcci�n de mail provista no es v�lida.");
define("_MSC_INVALIDEMAIL2","Por favor, verif�quela e int�ntelo de nuevo.");

define("_MSC_AVAVATARS","Avatares disponibles");

define("_MSC_SMILIES","Caritas");
define("_MSC_CLICKASMILIE","Presione sobre una carita para insertarla dentro de su mensaje.");
define("_MSC_CODE","C�digo");
define("_MSC_EMOTION","Carita");
?>