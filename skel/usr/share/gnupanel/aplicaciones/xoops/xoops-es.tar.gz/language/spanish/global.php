<?php
// $Id: global.php 747 2006-09-20 20:42:11Z skalpa $
//%%%%%%	File Name mainfile.php 	%%%%%
define('_PLEASEWAIT','Por Favor, aguarde');
define('_FETCHING','Cargando...');
define('_TAKINGBACK','Regresando...');
define('_LOGOUT','Desconectar');
define('_SUBJECT','Tema');
define('_MESSAGEICON','Icono del Mensaje');
define('_COMMENTS','Comentarios');
define('_POSTANON','Enviar an�nimamente');
define('_DISABLESMILEY','Desactivar caritas');
define('_DISABLEHTML','Desactivar html');
define('_PREVIEW','Previsualizar');

define('_GO','Continuar');
define("_NESTED","Vista escalonada");
define("_NOCOMMENTS","Sin comentarios");
define('_FLAT','Vista Plana');
define('_THREADED','Vista Jer�rquica');
define('_OLDESTFIRST','Viejos Primero');
define('_NEWESTFIRST','Nuevos Primero');
define("_MORE","m�s ....");
define("_MULTIPAGE","Para dividir el art�culo en m�ltiples p�ginas <br />inserte la palabra <font color=red>[pagebreak]</font> (con [] incluido) dentro del art�culo.");
define("_IFNOTRELOAD","Si la p�gina no carga autom�ticamente, <br />por favor, haga clic <a href='%s'>aqu�</a>");
define('_WARNINSTALL2','ATENCI�N: el Directorio %s existe en su servidor. <br />Por favor, elim�nelo por razones de seguridad.');
define('_WARNINWRITEABLE','ATENCI�N: el archivo %s es escribible por el servidor. <br />Por favor, cambie los permisos de este archivo por razones de seguridad. <br /> en Unix (444), en Win32 (s�lo lectura)');

// Error messages issued by XoopsObject::cleanVars()
define( "_XOBJ_ERR_REQUIRED", "%s requerido" );
define( "_XOBJ_ERR_SHORTERTHAN", "%s ha de tener menos de %d caracteres." );

//%%%%%%	File Name themeuserpost.php 	%%%%%
define('_PROFILE','Perfil');
define("_POSTEDBY",'Enviado por ');
define('_VISITWEBSITE','Ver Sitio');
define('_SENDPMTO','Enviar mensaje privado a %s');
define('_SENDEMAILTO','Enviar Correo a %s');
define('_ADD','Agregar');
define('_REPLY','Responder');
define('_DATE','Fecha');

//%%%%%%	File Name admin_functions.php 	%%%%%
define('_MAIN','Principal');
define('_MANUAL','Manual');
define('_INFO','Info');
define('_CPHOME','Panel de Control');
define('_YOURHOME','P�gina de inicio');

//%%%%%%	File Name misc.php (who's-online popup)	%%%%%
define('_WHOSONLINE','Usuarios en l�nea');
define('_GUESTS', 'Invitados');
define('_MEMBERS', 'Registrados');
define("_ONLINEPHRASE","<b>%s</b> usuario(s) en l�nea");
define("_ONLINEPHRASEX","<b>%s</b> usuario(s) navegando <b>%s</b>");
define('_CLOSE','Cerrar');

//%%%%%%	File Name module.textsanitizer.php 	%%%%%
define('_QUOTEC','Acotaci�n:');

//%%%%%%	File Name admin.php 	%%%%%
define('_NOPERM','Disculpe. Intenta acceder a zona restringida.');

//%%%%%		Common Phrases		%%%%%
define('_NO','No');
define('_YES','S�');
define('_EDIT','Editar');
define('_DELETE','Borrar');
define('_SUBMIT','Enviar');
define('_MODULENOEXIST','�El m�dulo seleccionado no existe!');
define("_ALIGN","Alinear");
define('_LEFT','Izquierda');
define('_CENTER','Centro');
define('_RIGHT','Derecha');
define('_FORM_ENTER','Por favor, indique %s');
// %s represents file name
define('_MUSTWABLE','�El archivo %s debe ser escribible por el servidor!');
// Module info
define('_PREFERENCES', 'Preferencias');
define('_VERSION','Versi�n');
define('_DESCRIPTION','Descripci�n');
define('_ERRORS','Errores');
define('_NONE','Nada');
define('_ON','el');
define('_READS','Lecturas');
define('_WELCOMETO','Bienvenido a %s');
define('_SEARCH','Buscar');
define('_ALL', 'todos');
define('_TITLE', 'T�tulo');
define('_OPTIONS', 'Opciones');
define('_QUOTE', 'Acotaci�n');
define('_LIST', 'Listar');
define('_LOGIN','Entrar');
define('_USERNAME','Nombre: ');
define('_PASSWORD','Contrase�a: ');
define('_SELECT','Seleccionar');
define('_IMAGE','Imagen');
define('_SEND','Enviar');
define('_CANCEL','Cancelar');
define('_ASCENDING','Orden Ascendente');
define('_DESCENDING','Orden Descendente');
define('_BACK', 'Regresar');
define('_NOTITLE', 'Sin t�tulo');

/* Image manager */
define('_IMGMANAGER','Administrador de Im�genes');
define('_NUMIMAGES', '%s im�genes');
define('_ADDIMAGE','Agregar Archivo de Imagen');
define('_IMAGENAME','Nombre');
define('_IMGMAXSIZE','Max. tama�o permitido (bytes):');
define('_IMGMAXWIDTH','Max. Ancho permitido (p�xeles):');
define('_IMGMAXHEIGHT','Max. Alto permitido (p�xeles):');
define('_IMAGECAT','Categor�a');
define('_IMAGEFILE','Archivo de Imagen');
define('_IMGWEIGHT','Orden para el administrador de im�genes');
define('_IMGDISPLAY','�Mostrar la imagen?');
define('_IMAGEMIME','MIME type');
define('_FAILFETCHIMG', 'Imposible subir el archivo %s');
define('_FAILSAVEIMG', 'Fallo almacenando la imagen %s dentro de la base de datos');
define('_NOCACHE', 'Sin Cach�');
define('_CLONE', 'Clonar');

//%%%%%	File Name class/xoopsform/formmatchoption.php 	%%%%%
define('_STARTSWITH','Comienza con');
define('_ENDSWITH','Termina con');
define('_MATCHES','Coincidencias');
define('_CONTAINS','Contiene');

//%%%%%%	File Name commentform.php 	%%%%%
define('_REGISTER','Registrar');

//%%%%%%	File Name xoopscodes.php 	%%%%%
define('_SIZE','Tama�o');  // font size
define('_FONT','Fuente');  // font family
define('_COLOR','Color');  // font color
define('_EXAMPLE','EJEMPLO');
define('_ENTERURL','Introduzca el URL del enlace que quiera agregar.');
define('_ENTERWEBTITLE','Introduzca el t�tulo del sitio web:');
define('_ENTERIMGURL','Introduzca el URL de la imagen que quiere agregar.                                              - Ejemplo: http://www.xoops.org/images/logo.gif ');
define('_ENTERIMGPOS','Defina ahora la posici�n de la imagen.');
define("_IMGPOSRORL","'R' o 'r' para Derecha, 'L' o 'l' para izquierda, o d�jela en blanco.");
define('_ERRORIMGPOS','�ERROR! Defina la posici�n de la imagen.');
define('_ENTEREMAIL','Introduzca la direcci�n de correo que quiere agregar.                                             - Ejemplo: yo@hotmail.com ');
define('_ENTERCODE','Indique los c�digos que desee agregar.');
define('_ENTERQUOTE','Inserte el texto que ser� acotado.');
define('_ENTERTEXTBOX','Por favor, inserte el texto dentro del cuadro de texto.');
define('_ALLOWEDCHAR','Longitud de caracteres max. permitida: ');
define('_CURRCHAR','Longitud actual de caracteres: ');
define('_PLZCOMPLETE','Por favor, cumplimente los campos tema y mensaje');
define('_MESSAGETOOLONG','Su mensaje es demasiado largo');

//%%%%%		TIME FORMAT SETTINGS   %%%%%
define('_SECOND', '1 segundo');
define('_SECONDS', '%s segundos');
define('_MINUTE', '1 minuto');
define('_MINUTES', '%s minutos');
define('_HOUR', '1 hora');
define('_HOURS', '%s horas');
define('_DAY', '1 d�a');
define('_DAYS', '%s d�as');
define('_WEEK', '1 semana');
define('_MONTH', '1 mes');

define('_DATESTRING','j/n/Y G:i:s');
define('_MEDIUMDATESTRING','j/n/Y G:i');
define('_SHORTDATESTRING','j/n/Y');
/*
The following characters are recognized in the format string:
a - 'am' or 'pm'
A - 'AM' or 'PM'
d - day of the month, 2 digits with leading zeros; i.e. '01' to '31'
D - day of the week, textual, 3 letters; i.e. 'Fri'
F - month, textual, long; i.e. 'January'
h - hour, 12-hour format; i.e. '01' to '12'
H - hour, 24-hour format; i.e. '00' to '23'
g - hour, 12-hour format without leading zeros; i.e. '1' to '12'
G - hour, 24-hour format without leading zeros; i.e. '0' to '23'
i - minutes; i.e. '00' to '59'
j - day of the month without leading zeros; i.e. '1' to '31'
l (lowercase 'L') - day of the week, textual, long; i.e. 'Friday'
L - boolean for whether it is a leap year; i.e. '0' or '1'
m - month; i.e. '01' to '12'
n - month without leading zeros; i.e. '1' to '12'
M - month, textual, 3 letters; i.e. 'Jan'
s - seconds; i.e. '00' to '59'
S - English ordinal suffix, textual, 2 characters; i.e. 'th', 'nd'
t - number of days in the given month; i.e. '28' to '31'
T - Timezone setting of this machine; i.e. 'MDT'
U - seconds since the epoch
w - day of the week, numeric, i.e. '0' (Sunday) to '6' (Saturday)
Y - year, 4 digits; i.e. '1999'
y - year, 2 digits; i.e. '99'
z - day of the year; i.e. '0' to '365'
Z - timezone offset in seconds (i.e. '-43200' to '43200')
*/


//%%%%%		LANGUAGE SPECIFIC SETTINGS   %%%%%
define("_CHARSET","ISO-8859-1");
define('_LANGCODE', 'es');

// change 0 to 1 if this language is a multi-bytes language
define("XOOPS_USE_MULTIBYTES","0");
?>