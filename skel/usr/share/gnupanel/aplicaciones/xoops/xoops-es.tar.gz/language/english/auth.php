<?php
// $Id: $
//%%%%%%		File Name auth.php 		%%%%%

define('_AUTH_MSG_AUTH_METHOD',"using %s authentication method");
define('_AUTH_LDAP_EXTENSION_NOT_LOAD','PHP LDAP extension not loaded (verify your PHP configuration file php.ini)');
define('_AUTH_LDAP_SERVER_NOT_FOUND',"Can't connect to the server");
define('_AUTH_LDAP_USER_NOT_FOUND',"Member %s not found in the directory server (%s) in %s");
define('_AUTH_LDAP_CANT_READ_ENTRY',"Can't read entry %s");
define('_AUTH_LDAP_XOOPS_USER_NOTFOUND',"Sorry no corresponding user information has been found in the XOOPS database for connection: %s <br>" .
		"Please verify your user datas or set on the automatic provisionning");
define('_AUTH_LDAP_START_TLS_FAILED',"Failed to open a TLS connection");		
		
?>