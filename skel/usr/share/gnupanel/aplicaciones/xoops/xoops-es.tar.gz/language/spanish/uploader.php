<?php
define("_ER_UP_MIMETYPELOAD", "Error leyendo la definici�n de mimetypes");
define("_ER_UP_FILENOTFOUND", "Archivo no encontrado");
define("_ER_UP_INVALIDFILESIZE", "Tama�o inv�lido");
define("_ER_UP_FILENAMEEMPTY", "Nombre de archivo vac�o");
define("_ER_UP_NOFILEUPLOADED", "Archivo no subido");
define("_ER_UP_ERROROCCURRED", "Ocurri� un error: Error #%s");
define("_ER_UP_UPLOADDIRNOTSET", "Directorio de Subidas no configurado");
define("_ER_UP_FAILEDOPENDIR", "Fall� la apertura del directorio: %s");
define("_ER_UP_FAILEDOPENDIRWRITE", "Fallo de escritura en el directorio: %s");
define("_ER_UP_FILESIZETOOLARGE", "Archivo demasiado grande (Max. %u bytes): %u bytes");
define("_ER_UP_FILEWIDTHTOOLARGE", "Anchura del archvio excesiva (Max. %u px): %u px");
define("_ER_UP_FILEHEIGHTTOOLARGE", "Altura del archivo excesiva (Max. %u px): %u px");
define("_ER_UP_MIMETYPENOTALLOWED", "MIME type no permitido: %s");
define("_ER_UP_FAILEDUPLOADFILE", "Error al subir el archivo: %s");
define("_ER_UP_FAILEDFETCHIMAGESIZE", "Failed fetching image size of %s, skipping max dimension check..");
define("_ER_UP_UNKNOWNFILETYPEREJECTED", "Tipo de archivo desconocido rechazado");
define("_ER_UP_ERRORSRETURNED", "Errores en la subida (upload)");
define("_ER_UP_INVALIDIMAGEFILE", "Archivo de imagen inv�lido");
define("_ER_UP_SUSPICIOUSREFUSED", "Archivo sospechoso rechazado");
define("_ER_UP_INVALIDFILENAME", "Nombre de archivo inv�lido");
define("_ER_UP_FAILEDSAVEFILE", "Error al guardar el archivo en %s");
?>