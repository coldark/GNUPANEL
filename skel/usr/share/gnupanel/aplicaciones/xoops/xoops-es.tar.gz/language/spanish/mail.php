<?php
define("_MAIL_MSGBODY", "Cuerpo del mensaje no configurado.");
define("_MAIL_FAILOPTPL", "Fallo abriendo el archivo de la plantilla.");
define("_MAIL_FNAMENG", "Desde Nombre no est� configurado.");
define("_MAIL_FEMAILNG", "Desde Correo no est� configurado.");
define("_MAIL_SENDMAILNG", "Imposible enviar el correo a %s.");
define("_MAIL_MAILGOOD", "Correo enviado a %s.");
define("_MAIL_SENDPMNG", "Imposible enviar el mensaje privado a %s.");
define("_MAIL_PMGOOD", "Mensaje privado enviado a %s.");
?>