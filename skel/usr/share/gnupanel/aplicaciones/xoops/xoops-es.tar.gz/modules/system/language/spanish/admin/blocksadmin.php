<?php // Xoops Spanish Support (http://www.esxoops.com)
// $Id: blocksadmin.php 507 2006-05-26 23:39:35Z skalpa $
//%%%%%%	Admin Module Name  Blocks 	%%%%%
define("_AM_DBUPDATED",_MD_AM_DBUPDATED);

//%%%%%%	blocks.php 	%%%%%
define('_AM_BADMIN','Administraci�n de Bloques');
define('_AM_ADDBLOCK','Agregar Bloque');
define('_AM_LISTBLOCK','Listar Todos los Bloques');
define('_AM_SIDE','Lado');
define('_AM_BLKDESC','Descripci�n');
define('_AM_TITLE','T�tulo');
define('_AM_WEIGHT','Ubicaci�n');
define('_AM_ACTION','Acci�n');
define('_AM_BLKTYPE','Tipo de Bloque');
define('_AM_LEFT','Izquierdo');
define('_AM_RIGHT','Derecho');
define('_AM_CENTER','Central');
define('_AM_VISIBLE','Visible');
define('_AM_POSCONTT','Posici�n del Contenido Adicional:');
define('_AM_ABOVEORG','Encima del contenido original');
define('_AM_AFTERORG','Debajo del contenido original');
define('_AM_EDIT','Editar');
define('_AM_DELETE','Borrar');
define('_AM_SBLEFT','Bloque Lateral Izquierdo');
define('_AM_SBRIGHT','Bloque Lateral Derecho');
define('_AM_CBLEFT','Bloque Central - Izquierdo');
define('_AM_CBRIGHT','Bloque Central - Derecho');
define('_AM_CBCENTER','Bloque Central - Central');   
define("_AM_CBBOTTOMLEFT","Bloque Central - Inferior Izquierda");
define("_AM_CBBOTTOMRIGHT","Bloque Central - Inferior Derecha");
define("_AM_CBBOTTOM","Bloque Central - Inferior");
define('_AM_CONTENT','Contenido');
define('_AM_OPTIONS','Opciones');
define('_AM_CTYPE','Tipo de Contenido');
define('_AM_HTML','HTML');
define('_AM_PHP','PHP Script');
define('_AM_AFWSMILE','Auto Formato (caritas activas)');
define('_AM_AFNOSMILE','Auto Formato (caritas apagadas)');
define('_AM_SUBMIT','Enviar');
define('_AM_CUSTOMHTML','Bloque Personalizado (HTML)');
define('_AM_CUSTOMPHP','Bloque Personalizado (PHP)');
define('_AM_CUSTOMSMILE','Bloque Personalizado (Auto Formato - Caritas Activas)');
define('_AM_CUSTOMNOSMILE','Bloque Personalizado (Auto Formato - Caritas Apagadas)');
define('_AM_DISPRIGHT','S�lo los de la Derecha');
define('_AM_SAVECHANGES','Guardar Cambios');
define('_AM_EDITBLOCK','Editar un bloque');
define('_AM_SYSTEMCANT','&iexcl;los bloques del Sistema no pueden se Eliminados!');
define('_AM_MODULECANT','&iexcl;Este Bloque No puede ser Eliminado Directamente! Si desea deshabilitar el Bloque primero desactive el m�dulo.');
define('_AM_RUSUREDEL','�Realmente desea eliminar el Bloque <b>%s</b>?');
define('_AM_NAME','Nombre');
define('_AM_USEFULTAGS','Tags �tiles:');
define('_AM_BLOCKTAG1','%s imprimir� %s');
define('_AM_SVISIBLEIN', 'Mostrar Bloques visibles en %s');
define('_AM_TOPPAGE', 'P�gina Inicio');
define('_AM_VISIBLEIN','Visible en');
define('_AM_ALLPAGES','En Todas');
define('_AM_TOPONLY','S�lo en Inicio');
define('_AM_ADVANCED','Configuraci�n Avanzada');
define('_AM_BCACHETIME','Duraci�n del Cach�');
define('_AM_BALIAS', 'Apodo (nick)');
define('_AM_CLONE', 'Clonar');  // clonar un bloque
define('_AM_CLONEBLK', 'Clon'); // Bloque Clonado
define('_AM_CLONEBLOCK', 'Clonar el bloque');
define('_AM_NOTSELNG', "&iexcl;'%s' No est� seleccionado!"); // error message
define('_AM_EDITTPL', 'Editar Plantilla');
define('_AM_MODULE', 'M�dulo');
define('_AM_GROUP', 'Grupo');
define('_AM_UNASSIGNED', 'No asignado');
?>