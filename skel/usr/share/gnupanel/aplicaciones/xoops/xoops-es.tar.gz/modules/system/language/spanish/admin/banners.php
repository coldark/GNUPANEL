<?php // Xoops Spanish Support (http://www.esxoops.com)
// $Id: banners.php 2 2005-11-02 18:23:29Z skalpa $
//%%%%%%        Admin Module Name  Banners         %%%%%
define("_AM_DBUPDATED",_MD_AM_DBUPDATED);

define("_AM_CURACTBNR","Banners Actualmente Activos");
define("_AM_BANNERID","ID del Banner");
define("_AM_IMPRESION","Impresiones");
define("_AM_IMPLEFT","Imp. que restan");
define("_AM_CLICKS","Clics");
define("_AM_NCLICKS","% Clics");
define("_AM_CLINAME","Nombre del Cliente");
define("_AM_FUNCTION","Funciones");
define("_AM_UNLIMIT","Ilimitado");
define("_AM_EDIT","Editar");
define("_AM_DELETE","Borrar");
define("_AM_FINISHBNR","Banners Finalizados");
define("_AM_IMPD","Imp.");
define("_AM_STARTDATE","Fecha Comenz�");
define("_AM_ENDDATE","Fecha Finaliz�");
define("_AM_ADVCLI","Clientes");
define("_AM_ACTIVEBNR","Banners Activos");
define("_AM_CONTNAME","Nombre de Contacto");
define("_AM_CONTMAIL","Correo de Contacto");
define("_AM_CLINAMET","Nombre del Cliente");
define("_AM_ADDNWBNR","Agregar Nuevo Banner");
define("_AM_IMPPURCHT","Impresiones Adquiridas:");
define("_AM_IMGURLT","URL de la Imagen:");
define("_AM_CLICKURLT","Clic URL:");
define("_AM_ADDBNR","Agregar Banner");
define("_AM_ADDNWCLI","A�adir Nuevo Cliente");
define("_AM_CONTNAMET","Nombre de Contacto:");
define("_AM_CONTMAILT","Correo de Contacto:");
define("_AM_CLILOGINT","Login del Cliente:");
define("_AM_CLIPASST","Contrase�a del Cliente:");
define("_AM_ADDCLI","A�adir Cliente");
define("_AM_DELEBNR","Borrar Banner");
define("_AM_SUREDELE","�Realmente desea eliminar este Banner?");
define("_AM_NO","No");
define("_AM_YES","S�");
define("_AM_EDITBNR","Editar Banner");
define("_AM_ADDIMPT","Agregar m�s Impresiones:");
define("_AM_PURCHT","Adquiridas:");
define("_AM_MADET","Producidas:");
define("_AM_CHGBNR","Cambiar Banner");
define("_AM_DELEADC","Borrar Cliente");
define("_AM_SUREDELCLI","Eliminar� al cliente <b>%s</b> junto con todos sus Banners");
define("_AM_NOBNRRUN","Este cliente no tiene ning�n Banner Activo.");
define("_AM_WARNING","ATENCI�N");
define("_AM_ACTBNRRUN","Este cliente Tiene BANNERS ACTIVOS mostr�ndose en el sitio:");
define("_AM_SUREDELBNR","�Realmente desea eliminar al Cliente junto con todos sus Banners?");
define("_AM_EDITADVCLI","Editar Cliente");
define("_AM_EXTINFO","Info Extra:");
define("_AM_CHGCLI","Cambiar Cliente");
define("_AM_USEHTML","�Usar Html?");
define("_AM_CODEHTML","C�digo Html:");

?>