<?php // Xoops Spanish Support (http://www.esxoops.com)
// $Id: modulesadmin.php 2 2005-11-02 18:23:29Z skalpa $
//%%%%%%	File Name  modulesadmin.php 	%%%%%
define("_MD_AM_MODADMIN","Administraci�n de M�dulos");
define("_MD_AM_MODULE","M�dulo");
define("_MD_AM_VERSION","Versi�n");
define("_MD_AM_LASTUP","�ltima Actualizaci�n");
define("_MD_AM_DEACTIVATED","Desactivado");
define("_MD_AM_ACTION","Acci�n");
define("_MD_AM_DEACTIVATE","Desactivar");
define("_MD_AM_ACTIVATE","Activar");
define("_MD_AM_UPDATE","Actualizar");
define("_MD_AM_DUPEN","&iexcl;Duplicar la entrada en la tabla de m�dulos!");
define("_MD_AM_DEACTED","El m�dulo seleccionado ha sido Desactivado. Ahora podr� desinstalarlo de forma Segura.");
define("_MD_AM_ACTED","&iexcl;&iexcl;El m�dulo seleccionado ha sido Activado!!");
define("_MD_AM_UPDTED","&iexcl;El m�dulo seleccionado ha sido Actualizado!");
define("_MD_AM_SYSNO","El M�dulo no puede ser Desactivado");
define("_MD_AM_STRTNO","Este m�dulo est� configurado como su p�gina de inicio por defecto. Por favor, primero cambie el m�dulo de inicio en las preferencias de su sitio.");

// added in RC2
define("_MD_AM_PCMFM","Por favor, Confirme:");

// added in RC3
define("_MD_AM_ORDER","Orden");
define("_MD_AM_ORDER0","(0 = oculto)");
define("_MD_AM_ACTIVE","Activo");
define("_MD_AM_INACTIVE","Inactivo");
define("_MD_AM_NOTINSTALLED","No Instalado");
define("_MD_AM_NOCHANGE","No Cambiar");
define("_MD_AM_INSTALL","Instalar");
define("_MD_AM_UNINSTALL","Desinstalar");
define("_MD_AM_SUBMIT","Enviar");
define("_MD_AM_CANCEL","Cancelar");
define("_MD_AM_DBUPDATE","&iexcl;Base de Datos actualizada Satisfactoriamente!");
define("_MD_AM_BTOMADMIN","Regresar a la p�gina de administraci�n de m�dulos");

// %s represents module name
define("_MD_AM_FAILINS","Imposible  Instalar %s.");
define("_MD_AM_FAILACT","Imposible activar %s.");
define("_MD_AM_FAILDEACT","Imposible  desactivar %s.");
define("_MD_AM_FAILUPD","Imposible actualizar %s.");
define("_MD_AM_FAILUNINS","Imposible desinstalar %s.");
define("_MD_AM_FAILORDER","Imposible Reordenar %s.");
define("_MD_AM_FAILWRITE","Imposible Escribir en el men� de principal.");
define("_MD_AM_ALEXISTS","El m�dulo %s ya existe.");
define("_MD_AM_ERRORSC","Error(es):");
define("_MD_AM_OKINS","M�dulo %s instalado satisfactoriamente.");
define("_MD_AM_OKACT","M�dulo %s activado  satisfactoriamente.");
define("_MD_AM_OKDEACT","M�dulo %s desactivado satisfactoriamente.");
define("_MD_AM_OKUPD","M�dulo %s actualizado satisfactoriamente.");
define("_MD_AM_OKUNINS","M�dulo %s desinstalado satisfactoriamente.");
define("_MD_AM_OKORDER","M�dulo %s reordenado satisfactoriamente.");

define('_MD_AM_RUSUREINS', 'Presione el bot�n para Instalar el m�dulo');
define('_MD_AM_RUSUREUPD', 'Presione el bot�n para Actualizar el m�dulo');
define('_MD_AM_RUSUREUNINS', '�Realmente desea desinstalar el m�dulo?');
define('_MD_AM_LISTUPBLKS', 'Los siguientes bloques pueden ser actualizados. <br />Seleccione los bloques en los que desea que el contenido (template y opciones) pueda ser sobrescrito.<br />');
define('_MD_AM_NEWBLKS', 'Nuevos Bloques');
define('_MD_AM_DEPREBLKS', 'Bloques Desaprobados');
?>