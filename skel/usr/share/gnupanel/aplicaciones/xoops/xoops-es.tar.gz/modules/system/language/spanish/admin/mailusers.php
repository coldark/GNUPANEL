<?php // Xoops Spanish Support (http://www.esxoops.com)
// $Id: mailusers.php 2 2005-11-02 18:23:29Z skalpa $
//%%%%%%	Admin Module Name  MailUsers	%%%%%
define("_AM_DBUPDATED",_MD_AM_DBUPDATED);

//%%%%%%	mailusers.php 	%%%%%
define("_AM_SENDTOUSERS","Env�e el mensaje a los usuarios cuyo:");
define("_AM_SENDTOUSERS2","Enviar a:");
define("_AM_GROUPIS","Grupo (opcional)");
define("_AM_TIMEFORMAT","(Formato yyyy-mm-dd, opcional)");
define("_AM_LASTLOGMIN","�ltimo ingreso posterior a");
define("_AM_LASTLOGMAX","�ltimo ingreso anterior a");
define("_AM_REGDMIN","Fecha de registro posterior a");
define("_AM_REGDMAX","Fecha de registro anterior a");
define("_AM_IDLEMORE","�ltimo ingreso es mayor de X d�as atr�s (opcional)");
define("_AM_IDLELESS","�ltimo ingreso es menor de X d�as atr�s (opcional)");
define("_AM_MAILOK","Enviar mensaje solamente a los usuarios que acepten mensajes de notificaci�n (opcional)");
define("_AM_INACTIVE","Enviar mensaje a usuarios inactivos solamente (opcional)");
define("_AMIFCHECKD","Si marca esto todo el env�o de mensajes privados citado anteriormente ser� ignorado");
define("_AM_MAILFNAME","Desde Nombre (s�lo nombre)");
define("_AM_MAILFMAIL","Desde Correo (s�lo correo)");
define("_AM_MAILSUBJECT","Asunto");
define("_AM_MAILBODY","Mensaje");
define("_AM_MAILTAGS","Tags �tiles:");
define("_AM_MAILTAGS1","{X_UID} imprimir� ID de usuario");
define("_AM_MAILTAGS2","{X_UNAME} imprimir� nombre de usuario");
define("_AM_MAILTAGS3","{X_UEMAIL} imprimir� correo de usuario");
define("_AM_MAILTAGS4","{X_UACTLINK} imprimir� enlace de activaci�n");
define("_AM_SENDTO","Enviar a");
define("_AM_EMAIL","Correo");
define("_AM_PM","Mensaje Privado");
define("_AM_SENDMTOUSERS","Enviar mensaje a los usuarios");
define("_AM_SENT","Usuarios");
define("_AM_SENTNUM","%s - %s (total: %s usuarios)");
define("_AM_SENDNEXT","Pr�ximo");
define("_AM_NOUSERMATCH","No se encontraron coincidencias");
define("_AM_SENDCOMP","Completado el env�o de mensaje(s).");
?>