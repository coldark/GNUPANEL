<?php
// $Id: groups.php 2 2005-11-02 18:23:29Z skalpa $
//%%%%%%	Admin Module Name  AdminGroup 	%%%%%
define("_AM_DBUPDATED",_MD_AM_DBUPDATED);

define("_AM_EDITADG","Edit Groups");
define("_AM_MODIFY","Modify");
define("_AM_DELETE","Delete");
define("_AM_CREATENEWADG","Create New Group");
define("_AM_NAME","Name");
define("_AM_DESCRIPTION","Description");
define("_AM_INDICATES","* indicates required fields");
define("_AM_SYSTEMRIGHTS","System Admin rights");
define("_AM_ACTIVERIGHTS","Module Admin rights");
define("_AM_IFADMIN","If admin right for a module is checked, access right for the module will always be enabled.");
define("_AM_ACCESSRIGHTS","Module Access rights");
define("_AM_UPDATEADG","Update Group");
define("_AM_MODIFYADG","Modify Group");
define("_AM_DELETEADG","Delete Group");
define("_AM_AREUSUREDEL","Are you sure you want to delete this group?");
define("_AM_YES","Yes");
define("_AM_NO","No");
define("_AM_EDITMEMBER","Edit Members of this Group");
define("_AM_MEMBERS","Members");
define("_AM_NONMEMBERS","Non-members");
define("_AM_ADDBUTTON"," add --> ");
define("_AM_DELBUTTON","<--delete");
define("_AM_UNEED2ENTER","You need to enter required info!");

// Added in RC3
define("_AM_BLOCKRIGHTS","Block Access Rights");

define('_AM_FINDU4GROUP', 'Find users for this group');
define('_AM_GROUPSMAIN', 'Groups Main');

define('_AM_ADMINNO', 'There must be at least one user in the webmasters group');
?>