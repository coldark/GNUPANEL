<?php // Xoops Spanish Support (http://www.esxoops.com)
// $Id: blocks.php,v 1.14 2003/03/27 18:06:47 w4z004 Exp $
// Blocks
define("_MB_SYSTEM_ADMENU","Administraci�n");
define("_MB_SYSTEM_RNOW","<b>&iexcl;Reg�strese</b> Ahora!");
define("_MB_SYSTEM_LPASS","�Recuperar Contrase�a?");
define("_MB_SYSTEM_SEARCH","Buscar");
define("_MB_SYSTEM_ADVS","B�squeda Avanzada");
define("_MB_SYSTEM_VACNT","Mostrar Cuenta");
define("_MB_SYSTEM_EACNT","Editar Cuenta");
// RMV-NOTIFY
define("_MB_SYSTEM_NOTIF", "Notificaciones");
define("_MB_SYSTEM_LOUT","Desconectarse");
define("_MB_SYSTEM_INBOX","Bandeja de Entrada");
define("_MB_SYSTEM_SUBMS","Art�culos Enviados");
define("_MB_SYSTEM_WLNKS","Enlaces en Espera");
define("_MB_SYSTEM_BLNK","Enlaces Rotos");
define("_MB_SYSTEM_MLNKS","Enlaces Modif.");
define("_MB_SYSTEM_WDLS","Descargas en Espera");
define("_MB_SYSTEM_BFLS","Archivos Rotos");
define("_MB_SYSTEM_MFLS","Descargas Modif.");
define("_MB_SYSTEM_HOME","Inicio");
define("_MB_SYSTEM_RECO","Recomi�ndenos");
define("_MB_SYSTEM_PWWIDTH","Ancho de Ventana Emergente");
define("_MB_SYSTEM_PWHEIGHT","Alto de Ventana Emergente");
define("_MB_SYSTEM_LOGO","Archivo de imagen del Logo en el directorio %s");
define("_MB_SYSTEM_COMPEND", "Comentarios");

define("_MB_SYSTEM_LOGGEDINAS", "Se identific� como");
define("_MB_SYSTEM_SADMIN","Mostrar grupos Admin");
define("_MB_SYSTEM_SPMTO","Enviar mensaje privado a %s");
define("_MB_SYSTEM_SEMTO","Enviar correo a %s");

define("_MB_SYSTEM_DISPLAY","Mostrar %s miembros");
define("_MB_SYSTEM_DISPLAYA","Mostrar avatares");
define("_MB_SYSTEM_NODISPGR","No mostrar usuarios cuyo rango sea:");

define("_MB_SYSTEM_DISPLAYC","Mostrar %s comentarios");
define("_MB_SYSTEM_SECURE", "Login Seguro");

define("_MB_SYSTEM_NUMTHEME", "%s dise�os");
define("_MB_SYSTEM_THSHOW", "Mostrar Captura de Pantalla");
define("_MB_SYSTEM_THWIDTH", "Ancho de la Captura");
define('_MB_SYSTEM_REMEMBERME', 'Recu�rdeme');
?>