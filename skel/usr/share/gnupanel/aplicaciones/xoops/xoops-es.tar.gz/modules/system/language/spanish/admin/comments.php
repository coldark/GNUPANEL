<?php // Xoops Spanish Support (http://www.esxoops.com)
// $Id: comments.php 2 2005-11-02 18:23:29Z skalpa $
//%%%%%% Comment Manager %%%%%
define('_MD_AM_COMMMAN','Administrador de comentarios');

define('_MD_AM_LISTCOMM','Mostrar Comentarios');
define('_MD_AM_ALLMODS','Todos los M�dulos');
define('_MD_AM_ALLSTATUS','Cualquier Estado');
define('_MD_AM_MODULE','M�dulo');
define('_MD_AM_COMFOUND','%s comentario(s) encontrado(s).');
?>