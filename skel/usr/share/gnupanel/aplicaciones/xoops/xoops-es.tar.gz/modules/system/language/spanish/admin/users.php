<?php // Xoops Spanish Support (http://www.esxoops.com)
// $Id: users.php 2 2005-11-02 18:23:29Z skalpa $
//%%%%%%	Admin Module Name  Users 	%%%%%
define("_AM_DBUPDATED",_MD_AM_DBUPDATED);

define("_AM_AYSYWTDU","�Realmente desea eliminar al Usuario <b>%s</b>?");
define("_AM_BYTHIS","Borrar� toda la informaci�n del usuario permanentemente.");
define("_AM_YES","S�");
define("_AM_NO","No");
define("_AM_YMCACF","Debe Completar Todos los Campos Obligatorios");
define("_AM_CNRNU","Imposible registrar Usuario Nuevo.");
define("_AM_EDEUSER","Editar/Borrar Usuarios");
define("_AM_NICKNAME","Apodo ");
define("_AM_MODIFYUSER","Modificar Usuario");
define("_AM_DELUSER","Borrar Usuario");
define("_AM_GO","&iexcl;Ir!");
define("_AM_ADDUSER","A�adir Usuario");
define("_AM_NAME","Nombre");
define("_AM_EMAIL","Correo");
define("_AM_OPTION","Opci�n");
define("_AM_AVATAR","Avatar");
define("_AM_THEME","Dise�o");
define("_AM_AOUTVTEAD","Permitir a los dem�s Usuarios Ver esta direcci�n de correo");
define("_AM_URL","URL");
define("_AM_ICQ","ICQ");
define("_AM_AIM","AIM");
define("_AM_YIM","YIM");
define("_AM_MSNM","MSNM");
define("_AM_LOCATION","Pa�s/Localidad");
define("_AM_OCCUPATION","Ocupaci�n");
define("_AM_INTEREST","Intereses");
define("_AM_RANK","Rango");
define("_AM_NSRA","Sin Rango Especial Asignado");
define("_AM_NSRID","No hay Rangos Especiales En la base dse Datos");
define("_AM_ACCESSLEV","Nivel de Acceso");
define("_AM_SIGNATURE","Firma");
define("_AM_PASSWORD","Contrase�a");
define("_AM_INDICATECOF","* indica campos Obligatorios");
define("_AM_NOTACTIVE","Este usuario no ha sido activado. �Desea activarlo usted mismo?");
define("_AM_UPDATEUSER","Actualizar Usuario");
define("_AM_USERINFO","Info del Usuario");
define("_AM_USERID","ID del Usuario");
define("_AM_RETYPEPD","Confirme la Contrase�a");
define("_AM_CHANGEONLY","(S�lo para cambios)");
define("_AM_USERPOST","Env�os del Usuario");
define("_AM_STORIES","Art�culos");
define("_AM_COMMENTS","Comentarios");
define("_AM_PTBBTSDIYT","Presione sobre Sincronizar si piensa que los env�os del usuario no corresponden con el estado actual");
define("_AM_SYNCHRONIZE","Sincronizar");
define("_AM_USERDONEXIT","Usuario No Existe");
define("_AM_STNPDNM","Lo Lamento, las nuevas contrase�as no Coinciden, regrese e int�ntelo de nuevo");
define("_AM_CNGTCOM","No puedo determinar la totalidad de los Comentarios");
define("_AM_CNGTST","No puedo determinar la totalidad de los Art�culos");
define("_AM_CNUUSER","Usuario Imposible de Actualizar");
define("_AM_CNGUSERID","No puedo determinar la ID del Usuario");
define("_AM_LIST","Lista");
define("_AM_NOUSERS", "Usuarios no seleccionados");

define("_AM_CNRNU2","El nuevo usuario no pudo ser agregado a los grupos: %s.");
?>