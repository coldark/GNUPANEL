<?php
// $Id
//%%%%%% Avatar Manager %%%%%
define('_MD_AVATARMAN','Administrador de Avatares');

define('_MD_SYSAVATARS','Avatares del Sistema');
define('_MD_CSTAVATARS','Avatares Personalizados');
define('_MD_ADDAVT','Agregar Avatar');
define('_MD_USERS','Usuarios usando este avatar');
define('_MD_RUDELIMG','�Realmente desea borrar esta imagen?');
define('_MD_FAILDEL', 'Imposible borrar el avatar %s de la base de datos');
?>