<?php // Xoops Spanish Support (http://www.esxoops.com)
// $Id: findusers.php 839 2007-06-28 20:05:30Z malanciault $
//%%%%%%	File Name findusers.php 	%%%%%

define("_AM_FINDUS","Buscar Usuario");
define("_AM_AVATAR","Avatar");
define("_AM_REALNAME","Nombre Real");
define("_AM_REGDATE","Fecha de Alta");
define("_AM_EMAIL","Correo");
define("_AM_PM","PM");
define("_AM_URL","URL");
define("_AM_PREVIOUS","Previo");
define("_AM_NEXT","Pr�ximo");
define("_AM_USERSFOUND","%s usuario(s) encontrado(s)");

define("_AM_ACTUS","Usuarios Activos: %s");
define("_AM_INACTUS","Usuarios Inactivos: %s");
define("_AM_NOFOUND","Usuarios no encontrados");
define("_AM_UNAME","Nombre de Usuario");
define("_AM_ICQ","ICQ");
define("_AM_AIM","AIM");
define("_AM_YIM","YIM");
define("_AM_MSNM","MSNM");
define("_AM_LOCATION","Ubicaci�n");
define("_AM_OCCUPATION","Ocupaci�n");
define("_AM_INTEREST","Intereses");
define("_AM_URLC","URL");
define("_AM_LASTLOGMORE","�ltimo ingreso mayor de <span style='color:#ff0000;'>X</span> d�as atr�s");
define("_AM_LASTLOGLESS","�ltimo ingreso menor de <span style='color:#ff0000;'>X</span> d�as atr�s");
define("_AM_REGMORE","Fecha de registro mayor de <span style='color:#ff0000;'>X</span> d�as atr�s");
define("_AM_REGLESS","Fecha de ingreso menor de <span style='color:#ff0000;'>X</span> d�as atr�s");
define("_AM_POSTSMORE","N�mero de env�os mayor de <span style='color:#ff0000;'>X</span>");
define("_AM_POSTSLESS","N�mero de env�os menor de <span style='color:#ff0000;'>X</span>");
define("_AM_SORT","Ordenar por");
define("_AM_ORDER","Orden");
define("_AM_LASTLOGIN","�ltimo Ingreso");
define("_AM_POSTS","N�mero de env�os");
define("_AM_ASC","Orden Ascendente");
define("_AM_DESC","Orden Descendente");
define("_AM_LIMIT","N�mero de Usuarios por p�gina");
define("_AM_RESULTS","Buscar Resultados");
define("_AM_SHOWMAILOK", "Tipo de usuarios a mostrar");
define("_AM_MAILOK","S�lo usuarios que acepten correo");
define("_AM_MAILNG","S�lo usuarios que no acepten correo");
define("_AM_SHOWTYPE","Tipo de usuarios a mostrar");
define("_AM_ACTIVE","S�lo usuarios activos");
define("_AM_INACTIVE","S�lo usuarios inactivos");
define("_AM_BOTH","Todos los usuarios");
define("_AM_SENDMAIL","Enviar correo");
define("_AM_ADD2GROUP", "Agregar usuarios al grupo %s");

define("_AM_GROUPS", "Grupos");
?>