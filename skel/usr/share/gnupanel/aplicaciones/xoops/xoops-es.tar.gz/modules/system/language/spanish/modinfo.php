<?php // Xoops Spanish Support (http://www.esxoops.com)
// $Id: modinfo.php 2 2005-11-02 18:23:29Z skalpa $
// Module Info

// The name of this module
define('_MI_SYSTEM_NAME','Sistema');

// A brief description of this module
define('_MI_SYSTEM_DESC','Administraci�n de la configuraci�n del sitio');

// Names of blocks for this module (Not all module has blocks)
define('_MI_SYSTEM_BNAME2',  'Men� del Usuario');
define('_MI_SYSTEM_BNAME3',  'Login');
define('_MI_SYSTEM_BNAME4',  'Buscar');
define('_MI_SYSTEM_BNAME5',  'Contenidos en espera');
define('_MI_SYSTEM_BNAME6',  'Men�');
define('_MI_SYSTEM_BNAME7',  'Info del Sitio');
define('_MI_SYSTEM_BNAME8',  'Usuarios Contectados');
define('_MI_SYSTEM_BNAME9',  'Top Env�os');
define('_MI_SYSTEM_BNAME10', 'Max. Colaboradores');
define('_MI_SYSTEM_BNAME11', 'Comentarios Recientes');
// RMV-NOTIFY
define('_MI_SYSTEM_BNAME12', 'Opciones de Notificaci�n');
define('_MI_SYSTEM_BNAME13', 'Dise�os (themes)');

// Names of admin menu items
define('_MI_SYSTEM_ADMENU1',  'Banners');
define('_MI_SYSTEM_ADMENU2',  'Bloques');
define('_MI_SYSTEM_ADMENU3',  'Grupos');
define('_MI_SYSTEM_ADMENU5',  'M�dulos');
define('_MI_SYSTEM_ADMENU6',  'Preferencias');
define('_MI_SYSTEM_ADMENU7',  'Caritas');
define('_MI_SYSTEM_ADMENU9',  'Rangos de usuario');
define('_MI_SYSTEM_ADMENU10', 'Editar Usuario');
define('_MI_SYSTEM_ADMENU11', 'Correo a usuarios');
define('_MI_SYSTEM_ADMENU12', 'Encontrar Usuario');
define('_MI_SYSTEM_ADMENU13', 'Im�genes');
define('_MI_SYSTEM_ADMENU14', 'Avatares');
define('_MI_SYSTEM_ADMENU15', 'Juego de Plantillas');
define('_MI_SYSTEM_ADMENU16', 'Comentarios');
?>