<?php // Xoops Spanish Support (http://www.esxoops.com)
// $Id: groups.php 2 2005-11-02 18:23:29Z skalpa $
//%%%%%%	Admin Module Name  AdminGroup 	%%%%%
define("_AM_DBUPDATED",_MD_AM_DBUPDATED);

define("_AM_EDITADG","Editar Grupos");
define("_AM_MODIFY","Modificar");
define("_AM_DELETE","Borrar");
define("_AM_CREATENEWADG","Crear Nuevo Grupo");
define("_AM_NAME","Nombre");
define("_AM_DESCRIPTION","Descripci�n");
define("_AM_INDICATES","* indica campos requeridos");
define("_AM_SYSTEMRIGHTS","Privilegios de Admin del Sistema");
define("_AM_ACTIVERIGHTS","Privilegios de Admin de los m�dulos");
define("_AM_IFADMIN","Si los privilegios de administraci�n para un m�dulo fuesen marcados, el acceso para el m�dulo siempre quedar�a habilitato.");
define("_AM_ACCESSRIGHTS","Privilegios de Acceso al M�dulo");
define("_AM_UPDATEADG","Actualizar Grupo");
define("_AM_MODIFYADG","Modificar Grupo");
define("_AM_DELETEADG","Borrar Grupo");
define("_AM_AREUSUREDEL","�Realmente desea eliminar este grupo?");
define("_AM_YES","S�");
define("_AM_NO","No");
define("_AM_EDITMEMBER","Editar Miembros de este Grupo");
define("_AM_MEMBERS","Usuarios Registrados");
define("_AM_NONMEMBERS","No-Registrados");
define("_AM_ADDBUTTON"," agregar --> ");
define("_AM_DELBUTTON","<--borrar");
define("_AM_UNEED2ENTER","&iexcl;Es necesario que facilite la informaci�n requerida!");

// Added in RC3
define("_AM_BLOCKRIGHTS","Derechos de acceso al Bloque");

define('_AM_FINDU4GROUP', 'Buscar Usuarios para este Grupo');
define('_AM_GROUPSMAIN', 'Men� de Grupos');
define('_AM_ADMINNO', 'Debe haber al menos un usuario en el grupo de Administradores');
?>