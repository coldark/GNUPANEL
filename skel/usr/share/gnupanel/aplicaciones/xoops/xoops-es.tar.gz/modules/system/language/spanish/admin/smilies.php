<?php // Xoops Spanish Support (http://www.esxoops.com)
// $Id: smilies.php 2 2005-11-02 18:23:29Z skalpa $
//%%%%%%	Admin Module Name  Smilies 	%%%%%
define('_AM_DBUPDATED',_MD_AM_DBUPDATED);

define('_AM_SMILESCONTROL','Control de Caritas ');
define('_AM_CODE','C�digo');
define('_AM_SMILIE','Carita');
define('_AM_ACTION','Acci�n');
define('_AM_EDIT','Editar');
define('_AM_DEL','Borrar');
define('_AM_CNRFTSD','Imposible recuperar de la base de datos de Caritas.');
define('_AM_ADDSMILE','Agregar Carita');
define('_AM_EDITSMILE','Editar carita');
define('_AM_SMILECODE','C�digo de la Carita:');
define('_AM_SMILEURL','URL:');
define('_AM_SMILEEMOTION','Descripci�n:');
define('_AM_ADD','Agregar');
define('_AM_SAVE','Guardar');
define('_AM_WAYSYWTDTS','ATENCI�N: �Realmente desea eliminar esta Carita ?');
?>