<?php // Xoops Spanish Support (http://www.esxoops.com)
// $Id: admin.php 2 2005-11-02 18:23:29Z skalpa $
//%%%%%%	File Name  admin.php 	%%%%%
define('_MD_AM_DBUPDATED','�Base de datos actualizada correctamente!');

define('_MD_AM_CONFIG','Configuraci�n del Sistema');


// Admin Module Names
define('_MD_AM_ADGS','Grupos');
define('_MD_AM_BANS','Banners');
define('_MD_AM_BKAD','Bloques');
define('_MD_AM_MDAD','M�dulos');
define('_MD_AM_SMLS','Caritas');
define('_MD_AM_RANK','Rango de Usuarios');
define('_MD_AM_USER','Editar Usuarios');
define('_MD_AM_FINDUSER','Buscar Usuarios');
define('_MD_AM_PREF','Preferencias');
define('_MD_AM_VRSN','Versi�n');
define('_MD_AM_MLUS','Correo a Usuarios');
define('_MD_AM_IMAGES','Administrador de Im�genes');
define('_MD_AM_AVATARS', 'Avatares');
define('_MD_AM_TPLSETS', 'Plantillas');
define('_MD_AM_COMMENTS', 'Comentarios');

// Group permission phrases
define('_MD_AM_PERMADDNG','Imposible agregar permisos de Grupo (Permiso: %s Grupo: %s)');
define('_MD_AM_PERMADDOK','Permiso de Grupo agregado satisfactoriamente (Permiso: %s Grupo: %s)');
define('_MD_AM_PERMRESETNG','Imposible restablecer permiso de grupo para el m�dulo %s');
define('_MD_AM_PERMADDNGP', 'Todos los elementos padre deben ser seleccionados.');
?>