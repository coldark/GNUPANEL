<?php // Xoops Spanish Support (http://www.esxoops.com)
// $Id: userrank.php 2 2005-11-02 18:23:29Z skalpa $
//%%%%%%	Admin Module Name  UserRank 	%%%%%
define("_AM_DBUPDATED",_MD_AM_DBUPDATED);
define("_AM_RANKSSETTINGS","Configuraci�n Rango de Usuarios");
define("_AM_TITLE","T�tulo");
define("_AM_MINPOST","Min. Env�os");
define("_AM_MAXPOST","Max. Env�os");
define("_AM_IMAGE","Imagen");
define("_AM_SPERANK","Rangos Especiales");
define("_AM_ON","Activo");
define("_AM_OFF","Apagado");
define("_AM_EDIT","Editar");
define("_AM_DEL","Borrar");
define("_AM_ADDNEWRANK","Agregar Nuevo Rango");
define("_AM_RANKTITLE","T�tulo del Rango");
define("_AM_SPECIAL","Especial");
define("_AM_ADD","Agregar");
define("_AM_EDITRANK","Editar Rangos");
define("_AM_ACTIVE","activo");
define("_AM_SAVECHANGE","Guardar Cambios");
define("_AM_WAYSYWTDTR","ATENCI�N: �Realmente desea eliminar este Rango?");
define("_AM_YES","S�");
define("_AM_NO","No");
define("_AM_VALIDUNDER","(Un archivo de imagen v�lido en el Directorio <b>%s</b>)");
define("_AM_SPECIALCAN","(Los Rangos Especiales pueden ser asignados a usuarios independientemente del n�mero de env�os)");
define("_AM_ACTION","Acci�n");
?>