<?php // Xoops Spanish Support (http://www.esxoops.com)
// $Id: images.php 2 2005-11-02 18:23:29Z skalpa $
//%%%%%% Image Manager %%%%%


define('_MD_IMGMAIN','Administrador de Im�genes');

define('_MD_ADDIMGCAT','Agregar Categor�a:');
define('_MD_EDITIMGCAT','Editar Categor�a:');
define('_MD_IMGCATNAME','Nombre de la categor�a');
define('_MD_IMGCATRGRP','Indique qu� grupos podr�n administrar las Im�genes<br /><br /><span style="font-weight: normal;">Estos grupos tienen permitido usar el administrador de im�genes para Seleccionar pero no para subir. El Administrador tiene acceso autom�tico.</span>');
define('_MD_IMGCATWGRP','Seleccione los grupos que podr�n subir im�genes:<br /><br /><span style="font-weight: normal;">Uso t�pico para moderadores y administradores.</span>');
define('_MD_IMGCATWEIGHT','Orden de aparici�n en el administrador de im�genes');
define('_MD_IMGCATDISPLAY','�Mostrar esta categor�a?');
define('_MD_IMGCATSTRTYPE','Las im�genes ser�n subidas a:');
define('_MD_STRTYOPENG','&iexcl;Esto no podr� ser cambiado Luego!');
define('_MD_INDB','Almacenar en Modo binario en la base de datos (como binary "blob" data)');
define('_MD_ASFILE','Almacenar como Archivo (En el directorio /uploads/)<br />');
define('_MD_RUDELIMGCAT','�Est� seguro de que quiere borrar esta categor�a con todos sus archivos de im�genes?');
define('_MD_RUDELIMG','�Est� seguro de que quiere borrar este archivo de imagen?');

define('_MD_FAILDEL', 'Fallo borrando la imagen %s desde la base de datos');
define('_MD_FAILDELCAT', 'Fallo borrando la categor�a de imagen %s desde la base de datos');
define('_MD_FAILUNLINK', 'Fallo borrando la imagen  %s desde el directorio del servidor');
?>