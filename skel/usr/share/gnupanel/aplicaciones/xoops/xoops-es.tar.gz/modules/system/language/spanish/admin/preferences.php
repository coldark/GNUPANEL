<?php
// $Id: preferences.php 928 2007-08-04 14:37:22Z pemen $
//%%%%%%	Admin Module Name  AdminGroup 	%%%%%
// dont change
define("_AM_DBUPDATED",_MD_AM_DBUPDATED);

define("_MD_AM_SITEPREF","Preferencias");
define("_MD_AM_SITENAME","Nombre del Sitio");
define("_MD_AM_SLOGAN","Eslogan o Lema");
define("_MD_AM_ADMINML","Correo del Administrador");
define("_MD_AM_LANGUAGE","Lenguage por Defecto");
define("_MD_AM_STARTPAGE","M�dulo para la p�gina de inicio");
define("_MD_AM_NONE","Nada");
define("_MD_AM_SERVERTZ","Zona Horaria del Servidor");
define("_MD_AM_DEFAULTTZ","Zona Horaria por Defecto");
define("_MD_AM_DTHEME","Dise�o por Defecto");
define("_MD_AM_THEMESET","Dise�os (Theme Set)");
define("_MD_AM_ANONNAME","Nombre de Usuario para los no registrados");
define("_MD_AM_MINPASS","Tama�o m�nimo requerido para la contrase�a");
define("_MD_AM_NEWUNOTIFY","�Recibir notificaci�n cada vez que un usuario se registre en el sitio?");
define("_MD_AM_SELFDELETE","�Permitirle a los usuarios Borrar su propia cuenta?");
define("_MD_AM_LOADINGIMG","�Mostrar imagen de Cargando....?");
define("_MD_AM_USEGZIP","�Usar compresi�n gzip?  PHP version 4.0.5 o superior recomendada. Aseg�rese antes de activiarlo.");
define("_MD_AM_UNAMELVL","Nivel de permisibilidad para los nombres de los usuarios");
define("_MD_AM_STRICT","Estricto (s�lo letras y n�meros)");
define("_MD_AM_MEDIUM","Medio");
define("_MD_AM_LIGHT","Liviano (recomendado para caracteres multi-byte)");
define("_MD_AM_USERCOOKIE","Nombre del Cookie para el usuario.");
define("_MD_AM_USERCOOKIEDSC","Este cookie contiene solamente un nombre de usuario que es guardado en el PC durante todo un a�o (Si el usuario lo desea). Si el usuario tiene este cookie, el nombre de usuario ser� autom�ticamente insertado en el Bloque de Ingreso.");
define("_MD_AM_USEMYSESS","Usar Sesi�n personalizada");
define("_MD_AM_USEMYSESSDSC","Seleccione s� para personalizar los valores relacionados con la sesi�n.");
define("_MD_AM_SESSNAME","Nombre de la Sesi�n");
define("_MD_AM_SESSNAMEDSC","El Nombre de la Sesi�n (V�lido solamente cuando 'Usar Sesi�n personalizada' est� activado)");
define("_MD_AM_SESSEXPIRE","Expiraci�n de la Sesi�n ");
define("_MD_AM_SESSEXPIREDSC","M�xima duraci�n en minutos de una sesi�n (V�lido solamente cuando la opci�n 'Usar Sesi�n personalizada' est� activada). Trabaja �nicamente cuando usted est� usando PHP4.2.0 o superior.");
define("_MD_AM_BANNERS","�Activar banners?");
define("_MD_AM_MYIP","Su IP. Esta informaci�n permite que no se le compute en las impresiones de los banners");
define("_MD_AM_MYIPDSC","Este IP no ser� contado como una impresi�n para los banners");
define("_MD_AM_ALWDHTML","HTML permitidos en todos los env�os.");
define("_MD_AM_INVLDMINPASS","Valor Inv�lido para la m�nima longitud de la contrase�a.");
define("_MD_AM_INVLDUCOOK","Valor Inv�lido para el nombre del Cookie del usuario.");
define("_MD_AM_INVLDSCOOK","Valor Inv�lido para el nombre del Cookie de la sesi�n.");
define("_MD_AM_INVLDSEXP","Valor Inv�lido para el tiempo de expiraci�n");
define("_MD_AM_ADMNOTSET","Correo del admin no configurado");
define("_MD_AM_YES","S�");
define("_MD_AM_NO","No");
define("_MD_AM_DONTCHNG","�No cambiar!");
define("_MD_AM_REMEMBER","Recuerde hacerle un chmod 666 a este archivo para permitirle al sistema modificarlo adecuadamente.");
define("_MD_AM_IFUCANT","Si no puede cambiar el permiso deber� editarlo manualmente.");


define("_MD_AM_COMMODE","Modo por defecto para mostrar los comentarios");
define("_MD_AM_COMORDER","Orden de los comentarios mostrados por Defecto");
define("_MD_AM_ALLOWHTML","�Permitir HTML en env�os de usuarios?");
define("_MD_AM_DEBUGMODE","Modo debug");
define("_MD_AM_DEBUGMODEDSC","Distintas opciones de Debug. Un sitio web de producci�n tiene que tener Desactivada esta opci�n.");
define("_MD_AM_AVATARALLOW","�Permitir subir avatares propios?");
define('_MD_AM_AVATARMP','Env�os m�nimos requeridos');
define('_MD_AM_AVATARMPDSC','Ingrese el n�mero m�nimo de env�os requeridos para poder Subir un avatar propio');
define("_MD_AM_AVATARW","M�xima anchura del Avatar");
define("_MD_AM_AVATARH","M�xima altura del Avatar");
define("_MD_AM_AVATARMAX","Tama�o m�ximo para el Avatar (bytes)");
define("_MD_AM_AVATARCONF","Configuraci�n de Avatares");
define("_MD_AM_CHNGUTHEME","Cambiar el tema a todos los usuarios");
define("_MD_AM_NOTIFYTO","Notificar al Grupo:");
define("_MD_AM_ALLOWTHEME","�Permitir a los usuarios seleccionar el Dise�o?");
define("_MD_AM_ALLOWIMAGE","�Permitir a los usuarios mostrar archivos de im�genes en los env�os?");

define("_MD_AM_USERACTV","Requiere activaci�n del usuario (recomendado)");
define("_MD_AM_AUTOACTV","Activar autom�ticamente");
define("_MD_AM_ADMINACTV","Activaci�n por Administradores");
define("_MD_AM_ACTVTYPE","Indique el tipo de activaci�n para los usuarios nuevos registrados");
define("_MD_AM_ACTVGROUP","Enviar correo de activaci�n a:");
define("_MD_AM_ACTVGROUPDSC","V�lido s�lo cuando la Activaci�n por Administradores est� seleccionada");
define('_MD_AM_USESSL', '�Usar SSL para el login?');
define('_MD_AM_SSLPOST', 'Nombre de la variable SSL');
define('_MD_AM_SSLPOSTDSC', 'El nombre de la variable usado para transferir el valor de la sesi�n v�a POST. Si no est� seguro, configure cualquier nombre que sea dif�cil.');
define('_MD_AM_DEBUGMODE0','Apagado');
define('_MD_AM_DEBUGMODE1','Activar Debug (modo inline)');
define('_MD_AM_DEBUGMODE2','Activar Debug (modo ventana emergente)');
define('_MD_AM_DEBUGMODE3','Debug Templates Smarty');
define('_MD_AM_MINUNAME', 'Longitud m�nima requerida para el nombre de usuario');
define('_MD_AM_MAXUNAME', 'Longitud m�xima permitida para el nombre de usuario');
define('_MD_AM_GENERAL', 'Configuraci�n General');
define('_MD_AM_USERSETTINGS', 'Configuraci�n del Usuario');
define('_MD_AM_ALLWCHGMAIL', '�Permitirle a los usuarios cambiar su direcci�n de correo?');
define('_MD_AM_ALLWCHGMAILDSC', '');
define('_MD_AM_IPBAN', 'Bloqueo de IP');
define('_MD_AM_BADEMAILS', 'Especifique qu� cuentas de correo No Estar�n Disponibles');
define('_MD_AM_BADEMAILSDSC', 'Separar cada una con una <b>|</b>, case insensitive, regex enabled.');
define('_MD_AM_BADUNAMES', 'Especifique qu� nombres de usuario No Estar�n Disponibles');
define('_MD_AM_BADUNAMESDSC', 'Separar cada uno con un <b>|</b>, case insensitive, regex enabled.');
define('_MD_AM_DOBADIPS', '�Habilitar Bloqueo de IP?');
define('_MD_AM_DOBADIPSDSC', 'Si lo activa podr� especificar a qu� direcciones IP podr� denegarle el acceso.');
define('_MD_AM_BADIPS', 'Especifique qu� direcciones IP deber�an ser bloqueadas.<br />Separar cada una con un <b>|</b>, case insensitive, regex enabled.');
define('_MD_AM_BADIPSDSC', '^aaa.bbb.ccc permite deshabilitar visitantes con un IP que empieza con aaa.bbb.ccc<br />aaa.bbb.ccc$ permite deshabilitar visitantes con un IP que termina con  aaa.bbb.ccc<br />aaa.bbb.ccc  permite deshabilitar visitantes con un IP que contiene aaa.bbb.ccc');
define('_MD_AM_PREFMAIN', 'Men� de Preferencias');
define('_MD_AM_METAKEY', 'Meta Keywords  (Palabras clave)');
define('_MD_AM_METAKEYDSC', 'Son palabras clave que representan el contenido de su sitio. Escriba las palabras separadas por una coma o un espacio. (Ej. XOOPS, PHP, mySQL, portal system)');
define('_MD_AM_METARATING', 'Meta Rating');
define('_MD_AM_METARATINGDSC', 'Define para qu� tipo de p�blico es apta su web');
define('_MD_AM_METAOGEN', 'General');
define('_MD_AM_METAO14YRS', '14 a�os');
define('_MD_AM_METAOREST', 'Restringido');
define('_MD_AM_METAOMAT', 'Mayores');
define('_MD_AM_METAROBOTS', 'Meta Robots');
define('_MD_AM_METAROBOTSDSC', 'Define qu� contenido buscar�n los Buscadores y los Bots');
define('_MD_AM_INDEXFOLLOW', 'Indexar, Continuar');
define('_MD_AM_NOINDEXFOLLOW', 'No Indexar, Continuar');
define('_MD_AM_INDEXNOFOLLOW', 'Indexar, No Continuar');
define('_MD_AM_NOINDEXNOFOLLOW', 'No Indexar, No Continuar');
define('_MD_AM_METAAUTHOR', 'Meta Autor');
define('_MD_AM_METAAUTHORDSC', 'Define el nombre del autor del documento que est� siendo le�do. Los formatos soportados incluyen el nombre, direcci�n del administrador, webmaster, nombre de la compa�ia o URL.');
define('_MD_AM_METACOPYR', 'Meta Copyright');
define('_MD_AM_METACOPYRDSC', 'Define cualquier estado de copyright del que usted desee informar acerca de los documentos de su sitio.');
define('_MD_AM_METADESC', 'Meta Descripci�n');
define('_MD_AM_METADESCDSC', 'Es una descripci�n general del contenido de su sitio');
define('_MD_AM_METAFOOTER', 'Meta Tags y Pie de P�gina');
define('_MD_AM_FOOTER', 'Pie de P�gina');
define('_MD_AM_FOOTERDSC', 'Aseg�rese de que los enlaces comiencen con http://, de otra manera el enlace no funcionar� correctamente.');
define('_MD_AM_CENSOR', 'Censura de Palabras');
define('_MD_AM_DOCENSOR', '�Activar el censor de palabras no deseadas?');
define('_MD_AM_DOCENSORDSC', 'Palabras que ser�n censuradas si el censor est� activo. Esta opci�n puede apagarse para acelerar la velocidad del sitio.');
define('_MD_AM_CENSORWRD', 'Palabras a Censurar');
define('_MD_AM_CENSORWRDDSC', 'Ingrese las palabras a censurar en los env�os.<br />Separadas con un <b>|</b>, case insensitive.');
define('_MD_AM_CENSORRPLC', 'Las palabras censuradas ser�n reemplazadas con:');
define('_MD_AM_CENSORRPLCDSC', 'Las palabras censuradas ser�n reemplazadas con los caracteres que usted indique');

define('_MD_AM_SEARCH', 'Opciones de B�squeda');
define('_MD_AM_DOSEARCH', '�Activar B�squedas Globales?');
define('_MD_AM_DOSEARCHDSC', 'Permitir buscar en Env�os/�tems del sitio completo.');
define('_MD_AM_MINSEARCH', 'Longitud m�nima de palabra');
define('_MD_AM_MINSEARCHDSC', 'Para poder realizar una b�squeda la palabra usada tendr� como m�nimo una longitud de:');
define('_MD_AM_MODCONFIG', 'Opciones de configuraci�n del m�dulo');
define('_MD_AM_DSPDSCLMR', '�Mostrar Condiciones de Registro?');
define('_MD_AM_DSPDSCLMRDSC', 'Seleccione s� para mostrar las condiciones de Registro en la p�gina de Registro');
define('_MD_AM_REGDSCLMR', 'Condiciones de Registro');
define('_MD_AM_REGDSCLMRDSC', 'Defina el Texto que se mostrar� como Condiciones de Registro');
define('_MD_AM_ALLOWREG', '�Permitir el registro de nuevos usuarios?');
define('_MD_AM_ALLOWREGDSC', 'Seleccione s� para aceptar el registro de nuevos usuarios');
define('_MD_AM_THEMEFILE', '�Comprobar cambios en las plantillas? (templates)');
define('_MD_AM_THEMEFILEDSC', 'Si activa este par�metro podr� ver aplicados inmediatamente los cambios realizados a su dise�o o plantilla. Desact�velo una vez concluidas las modificaciones.');
define('_MD_AM_CLOSESITE', '�Cerrar el sitio?');
define('_MD_AM_CLOSESITEDSC', 'Seleccione s� para cerrar su sitio. S�lo los usuarios incluidos en los grupos seleccionados tendr�n acceso a �l. ');
define('_MD_AM_CLOSESITEOK', 'Seleccione los grupos que tienen permitido el acceso mientras el sitio permanece Cerrado.');
define('_MD_AM_CLOSESITEOKDSC', 'Los usuarios del grupo Administradores siempre tendr�n el acceso garantizado.');
define('_MD_AM_CLOSESITETXT', 'Raz�n para el cierre temporal del sitio');
define('_MD_AM_CLOSESITETXTDSC', 'El texto que se presentar� mientras el sitio permanezca cerrado.');
define('_MD_AM_SITECACHE', 'Cach� Ampliado');
define('_MD_AM_SITECACHEDSC', 'Haga uso del Cach� para el contenido completo del sitio durante un per�odo espec�fico de tiempo. Su buen uso incrementar� el rendimiento del sitio. Adem�s, configurando el Cach� Ampliado anular� el control del cach� a nivel de m�dulo, bloque, y a nivel de cach� de �tems del m�dulo si existiera.');
define('_MD_AM_MODCACHE', 'Cach� de M�dulos');
define('_MD_AM_MODCACHEDSC', 'Haga uso del Cach� para los contenidos de un m�dulo concreto y por un per�odo espec�fico de tiempo para incrementar el rendimiento del mismo. Configurando el Cach� Ampliado anular� el cach� a nivel del �tem del m�dulo si existiera.');
define('_MD_AM_NOMODULE', 'No se encontr� m�dulo que haga uso del cach�.');
define('_MD_AM_DTPLSET', 'Juego de Plantillas por defecto (Template set)');
define('_MD_AM_SSLLINK', 'URL de donde est� ubicada la p�gina de ingreso SSL');

// added for mailer
define("_MD_AM_MAILER","Configuraci�n del Correo Electr�nico");
define("_MD_AM_MAILER_MAIL","");
define("_MD_AM_MAILER_SENDMAIL","");
define("_MD_AM_MAILER_","");
define("_MD_AM_MAILFROM","Direcci�n del remitente");
define("_MD_AM_MAILFROMDESC","El correo desde donde se env�a ej. mi_correo@no.es");
define("_MD_AM_MAILFROMNAME","Nombre del remitente");
define("_MD_AM_MAILFROMNAMEDESC","El nombre desde donde se env�a el correo<br /> ej: Administrador, etc.");
// RMV-NOTIFY
define("_MD_AM_MAILFROMUID","Usuario remitente");
define("_MD_AM_MAILFROMUIDDESC","Cuando el sistema env�a un mensaje privado, �Qu� usuario deber�a aparecer como remitente del mismo?");
define("_MD_AM_MAILERMETHOD","M�todo de env�o del correo");
define("_MD_AM_MAILERMETHODDESC","El m�todo usado por defecto es \"mail\" [ phpmail() ], utilice los otros �NICAMENTE si tiene problemas.");
define("_MD_AM_SMTPHOST","SMTP host(s)");
define("_MD_AM_SMTPHOSTDESC","Listado de servidores SMTP en donde intentar� la conexi�n <br /> ej. smtp.test.com");
define("_MD_AM_SMTPUSER","SMTPAuth nombre de usuario");
define("_MD_AM_SMTPUSERDESC","Nombre de Usuario para conectar a un host SMTP con SMTPAuth.");
define("_MD_AM_SMTPPASS","SMTPAuth password");
define("_MD_AM_SMTPPASSDESC","La contrase�a para conectar a un host SMTP con SMTPAuth.");
define("_MD_AM_SENDMAILPATH","Ruta para sendmail");
define("_MD_AM_SENDMAILPATHDESC","La ruta hacia el programa sendmail (o un sustituto) en el servidor.");
define("_MD_AM_THEMEOK","Dise�os seleccionables");
define("_MD_AM_THEMEOKDSC","Indique de entre qu� dise�os podr�n elegir los usuarios el suyo por defecto");
// Xoops Authentication constants
define("_MD_AM_AUTH_CONFOPTION_XOOPS", "Base de datos XOOPS");
define("_MD_AM_AUTH_CONFOPTION_LDAP", "Directorio LDAP est�ndar");
define("_MD_AM_AUTH_CONFOPTION_AD", "Microsoft Active Directory &copy");
define("_MD_AM_AUTHENTICATION", "Opciones de autentificaic�n");
define("_MD_AM_AUTHMETHOD", "M�todo de autentificaci�n");
define("_MD_AM_AUTHMETHODDESC", "�Qu� m�todo de autentificaci�n desea usar para el ingreso de los usuarios.");
define("_MD_AM_LDAP_MAIL_ATTR", "LDAP - Nombre del campo Correo");
define("_MD_AM_LDAP_MAIL_ATTR_DESC","El nombre del atributo E-MAIL en su �rbol de directorio LDAP.");
define("_MD_AM_LDAP_NAME_ATTR","LDAP - Nombre com�n del campo del nombre");
define("_MD_AM_LDAP_NAME_ATTR_DESC","El nombre del atributo del nombre com�n en su directorio LDAP.");
define("_MD_AM_LDAP_SURNAME_ATTR","LDAP - Nombre del campo del Apellido");
define("_MD_AM_LDAP_SURNAME_ATTR_DESC","El nombre del Apellido en su directorio LDAP.");
define("_MD_AM_LDAP_GIVENNAME_ATTR","LDAP - Nombre del campo Nombre facilitado");
define("_MD_AM_LDAP_GIVENNAME_ATTR_DSC","El nombre facilitado en su directorio LDAP.");
define("_MD_AM_LDAP_BASE_DN", "LDAP - Base DN");
define("_MD_AM_LDAP_BASE_DN_DESC", "La base DN (Distinguished Name) de su directorio LDAP");
define("_MD_AM_LDAP_PORT","LDAP - Puerto");
define("_MD_AM_LDAP_PORT_DESC","El puerto necesario para acceder a su directorio LDAP.");
define("_MD_AM_LDAP_SERVER","LDAP - Nombre del Servidor");
define("_MD_AM_LDAP_SERVER_DESC","El nombre de su directorio LDAP en el servidor.");

define("_MD_AM_LDAP_MANAGER_DN", "DN del administrador LDAP");
define("_MD_AM_LDAP_MANAGER_DN_DESC", "La DN del usuario que permite hacer b�squedas (ej: administrador)");
define("_MD_AM_LDAP_MANAGER_PASS", "Contrase�a del administrador de la LDAP");
define("_MD_AM_LDAP_MANAGER_PASS_DESC", "La contrase�a del usuario permite realizar b�squedas");
define("_MD_AM_LDAP_VERSION", "Versi�n del protocolo  LDAP");
define("_MD_AM_LDAP_VERSION_DESC", "Versi�n del protocolo LDAP : 2 � 3");

define("_MD_AM_LDAP_USETLS", " Usar conexi�n TLS");
define("_MD_AM_LDAP_USETLS_DESC", "Usar una conexi�n TLS (Transport Layer Security). TLS usa como puerto est�ndar el 389<BR>" .
								  " y la versi�n de LDAP debe ser configurado como 3.");

define("_MD_AM_LDAP_LOGINLDAP_ATTR","El atributo LDAP que usar� para buscar al usuario");
define("_MD_AM_LDAP_LOGINLDAP_ATTR_D","Cuando el uso de nombre de usuario en la opci�n DN es afirmativa, debe corresponder con el nombre de login de XOOPS");
define("_MD_AM_LDAP_LOGINNAME_ASDN", "Nombre de Login usado en la DN");
define("_MD_AM_LDAP_LOGINNAME_ASDN_D", "El nobre de Login de XOOPS es usado en la LDAP DN (eg : uid=<loginname>,dc=xoops,dc=org)<br>La entrada es directamente le�da en el servidor LDAP sin buscar");

define("_MD_AM_LDAP_FILTER_PERSON", "El filtro de b�squeda LDAP para buscar al usuario");
define("_MD_AM_LDAP_FILTER_PERSON_DESC", "Filtro especial LDAP para buscar usuario. @@loginname@@ es remplazado por el nombre de login<br> DEBE ESTAR EN BLANCO SI NO SABE DE QU� SE TRATA' !" .
		"<br>Ex : (&(objectclass=person)(samaccountname=@@loginname@@)) for AD" .
		"<br>Ex : (&(objectclass=inetOrgPerson)(uid=@@loginname@@)) for LDAP");

define("_MD_AM_LDAP_DOMAIN_NAME", "Nombre del dominio");
define("_MD_AM_LDAP_DOMAIN_NAME_DESC", "Nombre de dominio de Windows. Para servidores ADS y NT s�lamente");

define("_MD_AM_LDAP_PROVIS", "Aprovisionamiento autom�tico de cuentas Xoops");
define("_MD_AM_LDAP_PROVIS_DESC", "Crear base de datos del usuario en caso de no existir");

define("_MD_AM_LDAP_PROVIS_GROUP", "Grupo afectado por defecto");
define("_MD_AM_LDAP_PROVIS_GROUP_DSC", "Los nuevos usuarios ser�n asignado a estos grupos");

define("_MD_AM_LDAP_FIELD_MAPPING_ATTR", "Xoops-Auth server fields mapping");
define("_MD_AM_LDAP_FIELD_MAPPING_DESC", "Describir aqu� el mapping entre la base de datos de Xoops y el sistema de autentificaci�n LDAP." .
		"<br><br>Formato [Xoops Database field]=[Auth system LDAP attribute]" .
		"<br>por ejemplo : email=mail" .
		"<br>Separ cada uno de ellos con |" .
		"<br><br>!! Para usuarios avanzados !!");
		
define("_MD_AM_LDAP_PROVIS_UPD", "Mantenimiento del aprovisionamiento de cuentas Xoops");
define("_MD_AM_LDAP_PROVIS_UPD_DESC", "La cuenta de usuario Xoops ser� sincronizada siempre con el servidor de autentificaci�n");
		

?>