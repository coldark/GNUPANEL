<?php
/*************************************************************************************
   Copyright notice
   
   (c) 2002-2007 Oliver Georgi (oliver@phpwcms.de) // All rights reserved.
 
   This script is part of PHPWCMS. The PHPWCMS web content management system is
   free software; you can redistribute it and/or modify it under the terms of
   the GNU General Public License as published by the Free Software Foundation;
   either version 2 of the License, or (at your option) any later version.
  
   The GNU General Public License can be found at http://www.gnu.org/copyleft/gpl.html
   A copy is found in the textfile GPL.txt and important notices to the license 
   from the author is found in LICENSE.txt distributed with these scripts.
  
   This script is distributed in the hope that it will be useful, but WITHOUT ANY 
   WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
   PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 
   This copyright notice MUST APPEAR in all copies of the script!
*************************************************************************************/

// ----------------------------------------------------------------
// obligate check for phpwcms constants
if (!defined('PHPWCMS_ROOT')) {
   die("You Cannot Access This Script Directly, Have a Nice Day.");
}
// ----------------------------------------------------------------


// frontend login

$CNT_TMP .= headline($crow["acontent_title"], $crow["acontent_subtitle"], $template_default["article"]);

if(!empty($crow["acontent_template"]) && is_file(PHPWCMS_TEMPLATE.'inc_cntpart/felogin/'.$crow["acontent_template"])) {

	$_loginData					= @unserialize($crow["acontent_form"]);
			
	$_loginData['template']		= @file_get_contents(PHPWCMS_TEMPLATE.'inc_cntpart/felogin/'.$crow["acontent_template"]);

	$_loginData['form']			= get_tmpl_section('LOGIN_FORM', $_loginData['template']);
	$_loginData['logged_in']	= get_tmpl_section('LOGIN_IS', $_loginData['template']);
	
	// for future use
	//$_loginData['profile']		= get_tmpl_section('LOGIN_PROFIE', $_loginData['template']);

	/*
	if($_loginData['felogin_locale']) {
		$_loginData['old_locale']	= setlocale(LC_ALL, '0');
		setlocale(LC_ALL, $_loginData['felogin_locale']);
	}
	*/

	
	$_loginData['session_key']	= session_id();
	
	$_loginData['template']	= $_loginData['form'];
	$_loginData['error']	= false;
	$_loginData['login']	= '';
	$_loginData['password']	= '';
	$_loginData['remember']	= 0;		
	
	// handle Login
	if(isset($_POST['feLogin'])) {
	
		$_loginData['login']						= slweg($_POST['feLogin']);
		$_loginData['password']						= slweg($_POST['fePassword']);
		$_loginData['remember']						= empty($_POST['feRemember']) ? 0 : 1;
		
		$_loginData['validate_db']['userdetail']	= empty($_loginData['felogin_validate_userdetail'])  ? 0 : 1;
		$_loginData['validate_db']['backenduser']	= empty($_loginData['felogin_validate_backenduser']) ? 0 : 1;
		
		$_loginData['query_result'] = _checkFrontendUserLogin($_loginData['login'], md5($_loginData['password']), $_loginData['validate_db']);
		
		// ok, and now check if we got valid login data
		if($_loginData['query_result'] !== false && is_array($_loginData['query_result']) && count($_loginData['query_result'])) {
		
			$_SESSION[ $_loginData['session_key'] ]				= $_loginData['login'];
			$_SESSION[ $_loginData['session_key'].'_userdata']	= _getFrontendUserBaseData($_loginData['query_result']);
			
			if($_loginData['remember'] && !empty($_loginData['felogin_cookie_expire'])) {

				setcookie(	'phpwcmsFeLoginRemember', 
							$_loginData['login'].'##-|-##'.md5($_loginData['password']).'##-|-##'.$_loginData['validate_db']['userdetail'].'##-|-##'.$_loginData['validate_db']['backenduser'], 
							time()+$_loginData['felogin_cookie_expire'], '/', getCookieDomain() );
			
			}
		
		} else {
		
			$_loginData['error'] = true;
		
		}
	
	}
	
	if(_getFeUserLoginStatus()) {
		// user is logged in
		if(isset($_POST['feLogin'])) {
			headerRedirect(decode_entities(FE_CURRENT_URL));
		}
		$_loginData['template']	= $_loginData['logged_in'];
		$_loginData['template']	= str_replace('{LOGIN}', html_specialchars( $_SESSION[ $_loginData['session_key'] ] ), $_loginData['template']);
		
	} else {
	
		$_loginData['template'] = render_cnt_template($_loginData['template'], 'ERROR', ($_loginData['error'] ? 'login/pass wrong' : '') );
		$_loginData['template'] = render_cnt_template($_loginData['template'], 'LOGIN', html_specialchars($_loginData['login']));
		$_loginData['template'] = render_cnt_template($_loginData['template'], 'PASSWORD', '');
		$_loginData['template'] = render_cnt_template($_loginData['template'], 'REMEMBER', ($_loginData['remember'] ? ' checked="checked"' : '') );
	
	}
	
	//$_loginData['template'] = str_replace('{FORM_TARGET}', FE_CURRENT_URL, $_loginData['template']);
	$CNT_TMP .=  str_replace('{FORM_TARGET}', FE_CURRENT_URL, $_loginData['template']);


	/*
	// reset locale settings
	if(!empty($_loginData['old_locale'])) {
		setlocale(LC_ALL, $_loginData['old_locale']);
	}
	*/

}

?>