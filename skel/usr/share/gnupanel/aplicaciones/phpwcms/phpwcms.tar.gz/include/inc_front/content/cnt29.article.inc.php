<?php
/*************************************************************************************
   Copyright notice
   
   (c) 2002-2007 Oliver Georgi (oliver@phpwcms.de) // All rights reserved.

This script is part of PHPWCMS. The PHPWCMS web content management system is
free software; you can redistribute it and/or modify it under the terms of
the GNU General Public License as published by the Free Software Foundation;
either version 2 of the License, or (at your option) any later version.

The GNU General Public License can be found at http://www.gnu.org/copyleft/gpl.html
A copy is found in the textfile GPL.txt and important notices to the license
from the author is found in LICENSE.txt distributed with these scripts.

This script is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.  See the GNU General Public License for more details.

This copyright notice MUST APPEAR in all copies of the script!
*************************************************************************************/

//images (gallery)

$image	= @unserialize($crow["acontent_form"]);

// read template
if(empty($crow["acontent_template"]) && is_file(PHPWCMS_TEMPLATE.'inc_default/images.tmpl')) {

	$image['template']	= @file_get_contents(PHPWCMS_TEMPLATE.'inc_default/images.tmpl');
	
} elseif(is_file(PHPWCMS_TEMPLATE.'inc_cntpart/images/'.$crow["acontent_template"])) {

	$image['template']	= @file_get_contents(PHPWCMS_TEMPLATE.'inc_cntpart/images/'.$crow["acontent_template"]);

} else {

	$image['template']	= '';

}

if($image['template']) {

	$image['tmpl_header']		= get_tmpl_section('IMAGES_HEADER', $image['template']);
	$image['tmpl_footer']		= get_tmpl_section('IMAGES_FOOTER', $image['template']);
	$image['tmpl_entry']		= get_tmpl_section('IMAGES_ENTRY', $image['template']);
	$image['tmpl_entry_space']	= get_tmpl_section('IMAGES_ENTRY_SPACER', $image['template']);
	$image['tmpl_row_space']	= get_tmpl_section('IMAGES_ROW_SPACER', $image['template']);
	$image['tmpl_images']		= array();
	
	$image['template']  = $image['tmpl_header'];

	if(is_array($image['images']) && ($image['count'] = count($image['images']))) {

		// Start lightbox
		if(empty($image['lightbox'])) {
			$image['lightbox'] = false;
		} else {
			initializeLightbox();
			$image['lightbox'] = generic_string(5);
		}
		
		$image['center_image'] = (empty($image['center_image']) || !$image['width'] || !$image['height']) ? 0 : 1;
		
		$x   = 0;
		$col = 0;

		foreach($image['images'] as $key => $value) {
		
			$col++;
			
			// put spacer content between images
			if($col > 1) {
			
				$image['tmpl_images'][$x] .= $image['tmpl_entry_space'];
			
			} else {
			
				$image['tmpl_images'][$x]  = '';
			
			}

			$thumb_image = get_cached_image(
						array(	"target_ext"	=>	$image['images'][$key][3],
								"image_name"	=>	$image['images'][$key][2] . '.' . $image['images'][$key][3],
								"max_width"		=>	$image['images'][$key][4],
								"max_height"	=>	$image['images'][$key][5],
								"thumb_name"	=>	md5(	$image['images'][$key][2].$image['images'][$key][4].
															$image['images'][$key][5].$phpwcms["sharpen_level"]
														)
        					  )
						);

			if($image['zoom']) {

				$zoominfo = get_cached_image(
						array(	"target_ext"	=>	$image['images'][$key][3],
								"image_name"	=>	$image['images'][$key][2] . '.' . $image['images'][$key][3],
								"max_width"		=>	$phpwcms["img_prev_width"],
								"max_height"	=>	$phpwcms["img_prev_height"],
								"thumb_name"	=>	md5(	$image['images'][$key][2].$phpwcms["img_prev_width"].
															$phpwcms["img_prev_height"].$phpwcms["sharpen_level"]
														)
        					  )
						);
			}

			// now try to build caption and if neccessary add alt to image or set external link for image
			$caption	= getImageCaption($image['images'][$key][6]);
			// set caption and ALT Image Text for imagelist
			$capt_cur	= html_specialchars($caption[0]);
			$caption[3] = empty($caption[3]) ? '' : ' title="'.html_specialchars($caption[3]).'"'; //title
			$caption[1] = html_specialchars(empty($caption[1]) ? $image['images'][$key][1] : $caption[1]);

			$list_img_temp  = '<img src="'.PHPWCMS_IMAGES.$thumb_image[0].'" ';
			if($image['center_image']) {

				$img_margin_left	= ceil( ($image['width'] - $thumb_image[1]) / 2 );				
				$img_margin_right	= $image['width'] - $thumb_image[1] - $img_margin_left;
				$img_margin_top		= ceil( ($image['height'] - $thumb_image[2]) / 2 );
				$img_margin_bottom	= $image['height'] - $thumb_image[2] - $img_margin_top;
				
				$list_img_style		= 'style="margin:'.$img_margin_top.'px '.$img_margin_right.'px '.$img_margin_bottom.'px '.$img_margin_left.'px;" ';
				//$list_ahref_style	= 'style="padding:'.$img_margin_top.'px '.$img_margin_right.'px '.$img_margin_bottom.'px '.$img_margin_left.'px;display:block;" ';
				//$list_img_temp	   .= '{IMGSTYLE}';
				$list_ahref_style	= '';
				$list_img_temp	   .= $list_img_style;
				
			} else {
				$list_img_style		= '';
				$list_ahref_style	= '';
			}
			$list_img_temp .= $thumb_image[3].' alt="'.$caption[1].'"'.$caption[3].' border="0" />';
			$img_a			= '';

			if($image['zoom'] && isset($zoominfo) && $zoominfo != false) {
				// if click enlarge the image
				$open_popup_link = 'image_zoom.php?'.getClickZoomImageParameter($zoominfo[0].'?'.$zoominfo[3]);
				if($caption[2][0]) {
					$open_link = $caption[2][0];
					$return_false = '';
				} else {
					$open_link = $open_popup_link;
					$return_false = 'return false;';
				}
				
				if(!$image['lightbox'] || $caption[2][0]) {
				
					$img_a .= '<a href="'.$open_link."\" onclick=\"checkClickZoom();clickZoom('".$open_popup_link."','previewpic','width=";
					$img_a .= $zoominfo[1].",height=".$zoominfo[2]."');".$return_false.'"'.$caption[2][1];
					$img_a .= $list_ahref_style.'>';
					
					//$list_img_style = '';
					
				} else {
				
					// lightbox
					$img_a .= '<a href="'.PHPWCMS_IMAGES.$zoominfo[0].'" rel="lightbox['.$image['lightbox'].']" ';
					if($capt_cur) {
						$img_a .= 'title="'.parseLightboxCaption($capt_cur).'" ';
					}
					$img_a .= $list_ahref_style.'target="_blank">';
				
					//$list_img_style = '';
				
				}
				
				$img_a .= $list_img_temp.'</a>';
			} else {
				// if not click enlarge
				if($caption[2][0]) {
					$img_a .= '<a href="'.$caption[2][0].'" '.$list_ahref_style.$caption[2][1].'>'.$list_img_temp.'</a>';
					//$list_img_style = '';
				} else {
					$img_a .= $list_img_temp;
				}
			}
			
			$img_a = str_replace('{IMAGE}', $img_a, $image['tmpl_entry']);
			$img_a = str_replace('{IMGID}', $key, $img_a);
			//$img_a = str_replace('{IMGSTYLE}', $list_img_style, $img_a);
			$img_a = render_cnt_template($img_a, 'CAPTION', $image['nocaption'] ? '' : $capt_cur);
			
			$image['tmpl_images'][$x] .= $img_a;
			
			// check if this is the last image in row
			if($image['col'] == $col) {
				$x++;
				$col = 0;
			}
			
		}
		
		$image['template'] .= implode($image['tmpl_row_space'], $image['tmpl_images']);
	
	}
	
	$image['template'] .= $image['tmpl_footer'];
	
	// now do main replacements
	$image['template']  = str_replace('{ID}', $crow['acontent_id'], $image['template']);
	$image['template']  = str_replace('{SPACE}', $image['space'], $image['template']);
	$image['template']  = render_cnt_template($image['template'], 'TITLE', html_specialchars($crow['acontent_title']));
	$image['template']  = render_cnt_template($image['template'], 'SUBTITLE', html_specialchars($crow['acontent_subtitle']));
	$image['template']  = render_cnt_template($image['template'], 'TEXT', $crow['acontent_text']);
	
	$CNT_TMP .= $image['template'];

}

unset($image);

?>