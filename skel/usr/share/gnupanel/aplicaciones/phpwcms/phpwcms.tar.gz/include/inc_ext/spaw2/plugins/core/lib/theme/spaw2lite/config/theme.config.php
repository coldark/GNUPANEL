<?php
// default button css class
$default_tb_button_css_class = "spaw2liteButton";
// default dropdown css class
$default_tb_dropdown_css_class = "spaw2liteDropdown";
// custom toolbar item styles
$custom_tbi_styles = array(
  'html' => "width: 50px; height: 17px;",
  'design' => "width: 50px; height: 17px;",
);
$custom_tbi_css_classes = array(
  'html' => "spaw2liteModeButton",
  'design' => "spaw2liteModeButton",
  'separator' => "spaw2liteSeparator"
)
?>