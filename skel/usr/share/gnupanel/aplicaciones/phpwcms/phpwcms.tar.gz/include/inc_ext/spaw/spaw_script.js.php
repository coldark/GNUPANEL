<?php


  header('Content-Type: application/x-javascript'); 
  
  /*
  include 'config/spaw_control.config.php';
  include 'class/util.class.php';

  if (SPAW_Util::getBrowser()=='Gecko')
  {
    include 'class/script_gecko.js.php';
  }
  else
  {
    include 'class/script.js.php';
  }
  */

$cur_base_path = dirname(__FILE__);
include($cur_base_path.'/config/spaw_control.config.php');
include(PHPWCMS_ROOT.'/include/inc_ext/spaw/class/util.class.php');

if (SPAW_Util::getBrowser()=='Gecko') {
	include(PHPWCMS_ROOT.'/include/inc_ext/spaw/class/script_gecko.js.php');
} else {
	include(PHPWCMS_ROOT.'/include/inc_ext/spaw/class/script.js.php');
}

?>