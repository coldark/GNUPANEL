<?php
$items = array
(
  new SpawTbButton('inserthtml', 'inserthtml', 'isInsertHtmlEnabled', '', 'insertHtmlClick'),
);
?>