// Loading Interactive Controls Externally

function _writeActiveXObject($string) {

	document.write($string);	
	
}