<?php

// do check here

// new function for sending email from any custom script
// based on phpwcms' settings
// function sendEmail($recipient='', $subject='email', $body='', $attach=array(), $isHTML=0, $from='', $fromName='', $sender='')

$form_name = '';
$form_email = '';
$ADVANCED = isset($_POST['formStatus']) ? intval($_POST['formStatus']) : 0;
$ERR = '';
$_sendEmail[0] = false; //default email send status array info

if(isset($_POST['formStatus'])) {
	
	switch($ADVANCED) {
	
		case 0:		// basic form
					if(!empty($_POST['name'])) {
						$form_name = $_POST['name'];
					} else {
						$ERR .= '<p>No name</p>';
					}
					if(!empty($_POST['email']) && is_valid_email($_POST['email'])) {
						$form_email = $_POST['name'];
					} else {
						$ERR .= '<p>Check email</p>';
					}
					if(isset($_POST['submitAdvanced'])) {
						$ADVANCED = 1;
					}
					if(empty($ERR) && $ADVANCED == 0) {
						//send email function
						//$_sendEmail = sendEmail('oliver@phpwcms.de', 'My subject', 'build a body', array(), 0, 'info@phpwcms.de');
					}
			
					break;
		
		case 1:		// advanced form
		
					// ...do advanced form check here
					break;
		
		// ...and so on
	
	
	}
}


if(!$_sendEmail[0] && $ADVANCED == 0) {

		//index.php?<?php echo $GLOBALS['cache_query_string']
?>
<form name="form1" method="post" action="index.php?id=<?php echo implode(',', $aktion) ?>">
<?php echo $ERR ?>
<p>Simple Form:</p>
<p>Name: <input name="name" type="text" id="name" value="" /></p>
<p>Email: <input name="email" type="text" id="email" /></p>
<p><input name="submitBasic" type="submit" id="submitBasic" value="Send Basic" />&nbsp;&nbsp;<input name="submitAdvanced" type="submit" id="submitAdvanced" value="Send Advanced" /><input name="formStatus" type="hidden" id="formStatus" value="0" /></p>
</form>
<?php
} elseif($_sendEmail[0] && $ADVANCED == 0) {
	
	echo 'basic form success';

}

/////////////////////////////////////////////////////////////////////////////


if(!$_sendEmail[0] && $ADVANCED == 1) {
?>
<form name="form1" method="post" action="index.php?id=<?php echo implode(',', $aktion) ?>">
<?php echo $ERR ?>
<p>Advanced Form:</p>
<p>Name: <input name="name" type="text" id="name" value="<?php echo $form_name?>" /></p>
<p>Email: <input name="email" type="text" id="email" value="<?php echo $form_email?>" /></p>
<p>Message: <textarea name="email" cols="50" rows="10" id="email"></textarea></p>
<p><input name="submit" type="submit" id="submit" value="Send" /><input name="formStatus" type="hidden" id="formStatus" value="1" /></p>
</form>
<?php
} elseif($_sendEmail[0] && $ADVANCED == 1) {
	
	echo 'advanced form success';

}


?>