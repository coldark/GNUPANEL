<?php
/*************************************************************************************
   Copyright notice
   
   (c) 2002-2007 Oliver Georgi (oliver@phpwcms.de) // All rights reserved.
 
   This script is part of PHPWCMS. The PHPWCMS web content management system is
   free software; you can redistribute it and/or modify it under the terms of
   the GNU General Public License as published by the Free Software Foundation;
   either version 2 of the License, or (at your option) any later version.
  
   The GNU General Public License can be found at http://www.gnu.org/copyleft/gpl.html
   A copy is found in the textfile GPL.txt and important notices to the license 
   from the author is found in LICENSE.txt distributed with these scripts.
  
   This script is distributed in the hope that it will be useful, but WITHOUT ANY 
   WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
   PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 
   This copyright notice MUST APPEAR in all copies of the script!
*************************************************************************************/

// general frontend login form

// if $_SESSION['frontend_user']['id'] = 0 or not set
if(empty($_SESSION['frontend_user']['id'])) {
?><form name="fe_login" method="post" action="<?php echo FE_CURRENT_URL ?>">
<table border="0" cellpadding="1" cellspacing="0" summary="">
  <tr>
    <td style="font-size:10px;font-family:Verdana, Arial, Helvetica, sans-serif">Login:&nbsp;</td>
    <td><input name="fe_user_login" type="text" id="fe_user_login" size="20" maxlength="30" style="font-size:12px;font-family:Verdana, Arial, Helvetica, sans-serif;width:130px;" /></td>
  </tr>
  <tr>
    <td style="font-size:10px;font-family:Verdana, Arial, Helvetica, sans-serif">Password:&nbsp;</td>
    <td><input name="fe_user_pass" type="text" id="fe_user_login" size="20" maxlength="100" style="font-size:12px;font-family:Verdana, Arial, Helvetica, sans-serif;width:130px;" /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" name="fe_user_submit" value="Login" style="margin-top:2px;font-size:10px;font-family:Verdana, Arial, Helvetica, sans-serif" /></td>
  </tr>
</table>
</form><?php
}


?>