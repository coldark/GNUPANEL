inc_captcha
===========

This is the "lib" part of the Solmetra FormValidator released under GPL.

For more information visit:
http://www.solmetra.com/en/disp.php/en_products/en_scripts/en_formvalidator

