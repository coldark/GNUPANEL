<?php
$indexpage['acat_name']		= 'Home';
$indexpage['acat_info']		= '';
$indexpage['acat_alias']	= 'index';
$indexpage['acat_aktiv']	= 1;
$indexpage['acat_public']	= 1;
$indexpage['acat_template']	= 1;
$indexpage['acat_hidden']	= 0;
$indexpage['acat_ssl']		= 0;
$indexpage['acat_regonly']	= 0;
$indexpage['acat_topcount']	= -1;
$indexpage['acat_maxlist']	= 0;
$indexpage['acat_redirect']	= '';
$indexpage['acat_timeout']	= '';
$indexpage['acat_nosearch']	= '';
$indexpage['acat_nositemap']	= 1;
$indexpage['acat_order']	= 0;
$indexpage['acat_permit']	= '';
$indexpage['acat_cntpart']	= '';
$indexpage['acat_pagetitle']= '';

?>