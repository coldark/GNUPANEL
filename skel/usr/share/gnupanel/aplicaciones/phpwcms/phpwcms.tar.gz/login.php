<?php
/*************************************************************************************
   Copyright notice
   
   (c) 2002-2007 Oliver Georgi (oliver@phpwcms.de) // All rights reserved.
 
   This script is part of PHPWCMS. The PHPWCMS web content management system is
   free software; you can redistribute it and/or modify it under the terms of
   the GNU General Public License as published by the Free Software Foundation;
   either version 2 of the License, or (at your option) any later version.
  
   The GNU General Public License can be found at http://www.gnu.org/copyleft/gpl.html
   A copy is found in the textfile GPL.txt and important notices to the license 
   from the author is found in LICENSE.txt distributed with these scripts.
  
   This script is distributed in the hope that it will be useful, but WITHOUT ANY 
   WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
   PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 
   This copyright notice MUST APPEAR in all copies of the script!
*************************************************************************************/

// session_name('hashID');
session_start();

$phpwcms	= array();
$BL			= array();

require_once ('config/phpwcms/conf.inc.php');
require_once ('include/inc_lib/default.inc.php');
require_once (PHPWCMS_ROOT.'/include/inc_lib/dbcon.inc.php');

require_once (PHPWCMS_ROOT.'/include/inc_lib/general.inc.php');
require_once (PHPWCMS_ROOT.'/include/inc_lib/backend.functions.inc.php');
require_once (PHPWCMS_ROOT.'/include/inc_lang/code.lang.inc.php');

$_SESSION['REFERER_URL'] = PHPWCMS_URL.'login.php';

// define vars
$err 		= 0;
$wcs_user 	= '';

// reset all inactive users
$sql  = "UPDATE ".DB_PREPEND."phpwcms_userlog SET ";
$sql .= "logged_in = 0, logged_change = '".time()."' ";
$sql .= "WHERE logged_in = 1 AND ( ".time()." - logged_change ) > ".intval($phpwcms["max_time"]);
mysql_query($sql, $db);


//load default language EN
require_once (PHPWCMS_ROOT.'/include/inc_lang/backend/en/lang.inc.php');

//define language and check if language file is available
if(isset($_POST['form_lang'])) {
	$_SESSION["wcs_user_lang"] = strtolower(substr(clean_slweg($_POST['form_lang']), 0, 2));
}
if(empty($_SESSION["wcs_user_lang"])) {
	$_SESSION["wcs_user_lang"] = strtolower( isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? substr( $_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2 ) : $phpwcms["default_lang"] );
}
if(isset($BL[strtoupper($_SESSION["wcs_user_lang"])]) && file_exists(PHPWCMS_ROOT.'/include/inc_lang/backend/'.$_SESSION["wcs_user_lang"].'/lang.inc.php')) {
	$_SESSION["wcs_user_lang_custom"] = 1;
} else {
	$_SESSION["wcs_user_lang"] 			= 'en'; //by ono
	$_SESSION["wcs_user_lang_custom"] 	= 0;
}
if(!empty($_SESSION["wcs_user_lang_custom"])) { 
	//use custom lang if available -> was set in login.php
	$BL['merge_lang_array'][0] = $BL['be_admin_optgroup_label'];
	$BL['merge_lang_array'][1] = $BL['be_cnt_field'];	
	include_once (PHPWCMS_ROOT.'/include/inc_lang/backend/'.$_SESSION["wcs_user_lang"].'/lang.inc.php');
	$BL['be_admin_optgroup_label'] = array_merge($BL['merge_lang_array'][0], $BL['be_admin_optgroup_label']);
	$BL['be_cnt_field'] = array_merge($BL['merge_lang_array'][1], $BL['be_cnt_field']);
}

//WYSIWYG EDITOR:
//0 = no wysiwyg editor (default)
//1 = FCKeditor
$_SESSION["WYSIWYG_EDITOR"]		= 0;
$_SESSION["dhtml_hiding"]		= 1;
$phpwcms["wysiwyg_editor"]		= intval($phpwcms["wysiwyg_editor"]);
$wysiwyg_template				= '';

if($phpwcms["wysiwyg_editor"]) {
	include_once ("include/inc_ext/phpsniff/phpSniff.class.php");
	$c = new phpSniff();
	
	if($c->browser_is("mz1.3+") || $c->browser_is("ns7+") || $c->browser_is("fx")) {
		$_SESSION["dhtml_hiding"] = 0;
	}
	
	switch($phpwcms["wysiwyg_editor"]) {
	/*
		case 1:	// HTMLarea
				if(	$c->browser_is("ie5.5+")	|| 
					$c->browser_is("mz1.3+")	|| 
					$c->browser_is("ns7+")		|| 
					$c->browser_is("fx")
					) $_SESSION["WYSIWYG_EDITOR"] = 1;
				break;
	*/
		case 1:	//SPAW2
				if(	$c->browser_is("ie5.5+") || 
					$c->browser_is("mz1.3+") || 
					$c->browser_is("ns7+")   || 
					$c->browser_is("fx")     || 
					$c->browser_is("op9+")			) {
					
					$_SESSION["WYSIWYG_EDITOR"] = 1;
					
					if(!empty($phpwcms['wysiwyg_template']['SPAW2'])) {
						$wysiwyg_template = convertStringToArray($phpwcms['wysiwyg_template']['SPAW2']);
						$wysiwyg_template = $wysiwyg_template[0];
					} else {
						$wysiwyg_template = 'toolbarset_standard';
					}
				
				}
				break;
				
		
		
		
		case 3:
		case 2:	// FCKeditor 2
				if(	$c->browser_is("ie5.5+") || $c->browser_is("mz1.3+") || $c->browser_is("ns7+") || $c->browser_is("fx")) {
					
					$_SESSION["WYSIWYG_EDITOR"] = 2;
					
					if(!empty($phpwcms['wysiwyg_template']['FCKeditor'])) {
						$wysiwyg_template = convertStringToArray($phpwcms['wysiwyg_template']['FCKeditor']);
						$wysiwyg_template = $wysiwyg_template[0];
					} else {
						$wysiwyg_template = 'Basic';
					}
				
				}
				break;
				
				// TinyMCE -> Experimental
		/*
		case 5: if(file_exists(PHPWCMS_ROOT.'/include/inc_ext/tiny_mce/tiny_mce.js')) {
					$_SESSION["WYSIWYG_EDITOR"] = 5;
					break;
				}
		*/
		
		case 4:	//Spaw
				if(	$c->browser_is("ie5.5+") || $c->browser_is("mz1.3+") || $c->browser_is("ns7+") || $c->browser_is("fx")) {
				
					$_SESSION["WYSIWYG_EDITOR"] = 4;
					
					if(!empty($phpwcms['wysiwyg_template']['SPAW'])) {
						$wysiwyg_template = convertStringToArray($phpwcms['wysiwyg_template']['SPAW']);
						$wysiwyg_template = $wysiwyg_template[0];
					} else {
						$wysiwyg_template = 'default';
					}
				
				}
				break;
		

	}
}

if(isset($_POST['form_aktion']) && $_POST['form_aktion'] == 'login') {

	$login_passed = 0;
	$wcs_user = slweg($_POST['form_loginname']);
	$wcs_pass = slweg($_POST['form_password']);
	
	$sql_query =	"SELECT * FROM ".DB_PREPEND."phpwcms_user WHERE usr_login='".
					aporeplace($wcs_user)."' AND usr_pass='".
					aporeplace(md5($wcs_pass))."' AND usr_aktiv=1 AND (usr_fe=1 OR usr_fe=2)";

	if($result = mysql_query($sql_query)) {
		if($row = mysql_fetch_assoc($result)) {
			$_SESSION["wcs_user"]			= $wcs_user;
			//$_SESSION["wcs_pass"]			= $wcs_pass;
			$_SESSION["wcs_user_name"] 		= ($row["usr_name"]) ? $row["usr_name"] : $wcs_user;
			$_SESSION["wcs_user_id"]		= $row["usr_id"];
			$_SESSION["wcs_user_aktiv"]		= $row["usr_aktiv"];
			$_SESSION["wcs_user_rechte"]	= $row["usr_rechte"];
			$_SESSION["wcs_user_email"]		= $row["usr_email"];
			$_SESSION["wcs_user_avatar"]	= $row["usr_avatar"];
			$_SESSION["wcs_user_logtime"]	= time();
			$_SESSION["wcs_user_admin"]		= $row["usr_admin"];
			$_SESSION["wcs_user_thumb"]		= 1;
			if($row["usr_lang"]) {
				$_SESSION["wcs_user_lang"]	= $row["usr_lang"];
			}
						
			$_SESSION["structure"]			= unserialize($row["usr_var_structure"]);
			$_SESSION["klapp"]				= unserialize($row["usr_var_privatefile"]);
			$_SESSION["pklapp"]				= unserialize($row["usr_var_publicfile"]);
			$row["usr_vars"]				= unserialize($row["usr_vars"]);
			$_SESSION["WYSIWYG_TEMPLATE"]	= empty($row["usr_vars"]['template']) ? $wysiwyg_template : $row["usr_vars"]['template'];
			$_SESSION["WYSIWYG_EDITOR"]		= $row["usr_wysiwyg"];
			
			$login_passed = 1;		
		}
		mysql_free_result($result);
	}
	
	if($login_passed) {
		//Schreiben der Login-Daten in Datenbank
		$check = mysql_query(	"SELECT COUNT(*) FROM ".DB_PREPEND."phpwcms_userlog WHERE logged_user='".
								aporeplace($wcs_user)."' AND logged_in=1", $db );
		if($row = mysql_fetch_row($check)) {
			if(!$row[0]) {
				//Wenn kein User gef�hrt wird, dann neu anlegen
				mysql_query("INSERT INTO ".DB_PREPEND."phpwcms_userlog ".
							"(logged_user, logged_username, logged_start, logged_change, ".
							"logged_in, logged_ip) VALUES ('".
							aporeplace($wcs_user)."', '".aporeplace($_SESSION["wcs_user_name"])."', ".time().", ".
							time().", 1, '".getRemoteIP()."')", $db );				
			}
		}
		mysql_free_result($check);
		$_SESSION['PHPWCMS_ROOT'] = PHPWCMS_ROOT;
		headerRedirect(PHPWCMS_URL."phpwcms.php?". session_name().'='.session_id());

	} else {
		$err = 1;
	}	
} else {
	//Updaten, wenn User ausgew�hlt
	$sql = 	"UPDATE ".DB_PREPEND."phpwcms_userlog SET logged_in = 0, logged_change = ". time() .
			"WHERE logged_in = 1 AND (" . time() ." - logged_change ) > ".intval($phpwcms["max_time"]);
	mysql_query($sql, $db);
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
	<title>phpwcms: LOGIN</title>
	<meta http-equiv="Content-Type" content="text/html; charset=<?php echo PHPWCMS_CHARSET ?>">
	<meta name="robots" content="noindex, nofollow">
	<link href="include/inc_css/login.css" rel="stylesheet" type="text/css">
	<script language="javascript" type="text/javascript" src="include/inc_js/phpwcms.js"></script>
<?php

if(isset($_SESSION["wcs_user_lang"]) && $_SESSION["wcs_user_lang"] == 'ar') {
	echo '	<style type="text/css">' . LF . '<!--' . LF . '* {direction: rtl;}' . LF . '//-->' . LF . '</style>';
} elseif(strtolower($phpwcms['default_lang']) == 'ar') {
	echo '	<style type="text/css">' . LF . '<!--' . LF . '* {direction: rtl;}' . LF . '//-->' . LF . '</style>';
}

?>
</head>

<body>
<table width="504" border="0" align="center" cellpadding="0" cellspacing="0" summary="Login Screen">
  <tr>
    <td colspan="3"><img src="img/leer.gif" alt="" width="1" height="12"></td>
  </tr>
  <tr>
    <td colspan="3"><img src="img/leer.gif" alt="" width="18" height="1"><a href="index.php" target="_top"><img src="img/backend/preinfo2.jpg" alt="phpwcms" width="122" height="31" border="0"></a></td>
  </tr>
  <tr>
    <td colspan="3"><img src="img/leer.gif" alt="" width="1" height="7"></td>
  </tr>
  <tr>
    <td colspan="3"><a href="index.php" target="_top"><img src="img/backend/preinfo2_r4_c2.jpg" alt="phpwcms" width="504" height="154" border="0"></a></td>
  </tr>
  <tr>
    <td colspan="3"><img src="img/leer.gif" alt="" width="1" height="11"></td>
  </tr>
  <tr>
    <td width="15" style="width:15px;"><img src="img/backend/preinfo2_r6_c2.gif" alt="" width="15" height="15" border="0"></td>
    <td width="474" bgcolor="#FFFFFF" style="width:474px;"><img src="img/backend/preinfo2_r6_c3.gif" alt="" width="474" height="15" border="0"></td>
    <td width="15" style="width:15px;"><img src="img/backend/preinfo2_r6_c7.gif" alt="" width="15" height="15" border="0"></td>
  </tr>
  <tr>
    <td style="background-image:url(img/backend/preinfo2_r7_c2.gif);background-repeat:repeat-y;" bgcolor="#FFFFFF">&nbsp;</td>
    <td bgcolor="#FFFFFF" style="padding-left:3px;padding-right:3px;" id="loginFormArea">
		<div class="error" style="font-weight:bold;padding:0 0 15px 0;font-size:12px;text-align:center"><?php
	
			echo $BL['be_login_jsinfo'];
	
		?></div></td>
    <td style="background-image:url(img/backend/preinfo2_r7_c7.gif);background-repeat:repeat-y;background-position:right;" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td style="background-image:url(img/backend/preinfo2_r7_c2.gif);background-repeat:repeat-y;" bgcolor="#FFFFFF">&nbsp;</td>
    <td bgcolor="#FFFFFF" style="padding: 0 3px 5px 3px;font-size:10px;"><strong><a href="http://www.phpwcms.de" target="_blank" style="text-decoration:none;">phpwcms</a></strong> Copyright &copy; 2003&#8212;2007
            Oliver Georgi. Extensions are copyright of their respective owners.
            Visit <a href="http://www.phpwcms.de" target="_blank">http://www.phpwcms.de</a> for
            details. phpwcms is free software released under <a href="http://www.fsf.org/licensing/licenses/gpl.html" target="_blank">GPL</a> and comes WITHOUT ANY WARRANTY. Obstructing the appearance of this notice is prohibited
      by law.
    </td>
    <td style="background-image:url(img/backend/preinfo2_r7_c7.gif);background-repeat:repeat-y;background-position:right;" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td><img src="img/backend/preinfo2_r9_c2.gif" alt="" width="15" height="15" border="0"></td>
    <td bgcolor="#FFFFFF"><img src="img/backend/preinfo2_r9_c3.gif" alt="" width="474" height="15" border="0"></td>
    <td><img src="img/backend/preinfo2_r9_c7.gif" alt="" width="15" height="15" border="0"></td>
  </tr>
</table>
<div id="loginForm" style="display:none;">
<form name="login_formular" method="post" action="login.php" autocomplete="off" style="margin:0;padding:0;">
	
	<?php 
		  
		echo '<h1>'.$BL["login_text"].'</h1>';
		
		if(file_exists('setup')) {
			echo '<div class="error" style="margin-top:10px;">'.$BL["setup_dir_exists"].'</div>';
		}
		if(file_exists('phpwcms_code_snippets')) {
			echo '<div class="error" style="margin-top:10px;">'.$BL["phpwcms_code_snippets_dir_exists"].'</div>';
		}
		
		if($err) {
			echo '<div class="error" style="margin-top:10px;font-weight:bold;">'.$BL["login_error"].'</div>';
		}
		
		
		?>	

	<table border="0" cellpadding="0" cellspacing="0" summary="Login Form" style="margin:15px 0 20px 10px">
        <tr>
          <td align="right" nowrap="nowrap" class="v10"><?php echo $BL["login_username"] ?>:&nbsp;</td>
          <td class="v10"><input name="form_loginname" type="text" id="form_loginname" style="width:250px;" size="30" maxlength="30" value="<?php echo html_specialchars($wcs_user); ?>"></td>
          </tr>
        <tr><td colspan="2"><img src="img/leer.gif" alt="" width="1" height="3"></td></tr>
        <tr>
          <td align="right" nowrap="nowrap" class="v10"><?php echo $BL["login_userpass"] ?>:&nbsp;</td>
          <td class="v10"><input name="form_password" type="password" id="form_password" style="width:250px;" size="30" maxlength="20"></td>
          </tr>
        <tr><td colspan="2"><img src="img/leer.gif" alt="" width="1" height="4"></td></tr>
        <tr>
          <td align="right" nowrap="nowrap" class="v10"><?php echo $BL["login_lang"] ?>:&nbsp;</td>
          <td class="v10"><select name="form_lang" id="form_lang" style="width:250px;">
            <?php
// check available languages installed and build language selector menu
$lang_dirs = opendir(PHPWCMS_ROOT.'/include/inc_lang/backend');
$lang_code = array();
while($lang_codes = readdir( $lang_dirs )) {
	if( $lang_codes != "." && $lang_codes != ".." && file_exists(PHPWCMS_ROOT.'/include/inc_lang/backend/'.$lang_codes."/lang.inc.php")) {
		$lang_code[$lang_codes]  = '<option value="'.$lang_codes.'"';
		$lang_code[$lang_codes] .= ($lang_codes == $_SESSION["wcs_user_lang"]) ? ' selected="selected"' : '';
		$lang_code[$lang_codes] .= '>';
		$lang_code[$lang_codes] .= (isset($BL[strtoupper($lang_codes)])) ? $BL[strtoupper($lang_codes)] : strtoupper($lang_codes);
		$lang_code[$lang_codes] .= '</option>';
	}
}
closedir( $lang_dirs );

	ksort($lang_code);
	
	echo implode(LF, $lang_code);


?>
          </select></td>
          </tr>
        <tr><td colspan="2"><img src="img/leer.gif" alt="" width="1" height="10"></td></tr>
        <tr>
          <td>&nbsp;</td>
          <td><input name="Submit" type="submit" value="<?php echo $BL["login_button"] ?>"><input name="form_aktion" type="hidden" id="form_aktion" value="login"></td>
          </tr>
    </table>
    </form>
</div>
<script language="javascript" type="text/javascript">
<!--
var loginHTML = getObjectById('loginForm');
var loginArea = getObjectById('loginFormArea');
loginArea.innerHTML = loginHTML.innerHTML;
loginHTML.innerHTML = '';
document.login_formular.form_loginname.focus();
//-->
</script>
</body>
</html>