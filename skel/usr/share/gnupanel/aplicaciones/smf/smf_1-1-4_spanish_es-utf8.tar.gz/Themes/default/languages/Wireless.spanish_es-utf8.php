<?php
// Version: 1.1; Wireless

$txt['wireless_error_home'] = '&Iacute;ndice del Foro';
$txt['wireless_error_notyet'] = 'Lo sentimos, esta secci&oacute;n no está disponible usuarios wireless en este momento.';

$txt['wireless_options'] = 'Opciones adicionales';
$txt['wireless_options_login'] = 'Ingresar';
$txt['wireless_options_logout'] = 'Salir';

$txt['wireless_navigation'] = 'Navegaci&oacute;n';
$txt['wireless_navigation_up'] = 'Subir un nivel';
$txt['wireless_navigation_next'] = 'P&aacute;gina Siguiente';
$txt['wireless_navigation_prev'] = 'P&aacute;gina Anterior';
$txt['wireless_navigation_index'] = '&Iacute;ndice de Mensajes';
$txt['wireless_navigation_topic'] = 'Volver al tema';

$txt['wireless_pm_inbox'] = 'Bandeja de entrada de MP';
$txt['wireless_pm_inbox_new'] = 'Bandeja de entrada de MP (<span style="color: red;">%d nuevo(s)</span>)';
$txt['wireless_pm_by'] = 'por';
$txt['wireless_pm_add_buddy'] = 'Agregar Amigo';
$txt['wireless_pm_select_buddy'] = 'Selecciona un amigo';
$txt['wireless_pm_search_member'] = 'Buscar usuario';
$txt['wireless_pm_search_name'] = 'Nombre';
$txt['wireless_pm_no_recipients'] = 'Sin destinatarios (todav&iacute;a)';
$txt['wireless_pm_reply'] = 'Responder';
$txt['wireless_pm_reply_to'] = 'Responder a';

$txt['wireless_recent_unread_posts'] = 'Mensajes no le&iacute;dos';
$txt['wireless_recent_unread_replies'] = 'Respuestas no le&iacute;das';

?>