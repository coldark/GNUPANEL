<?php
// Version: 1.1; Settings

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'Das Klassik Theme, welches die bahnbrechende PHP/MySQL Konvertierung von YaBB eingel&auml;utet und 2 Jahre begleitet hat, bis es von SMF abgel&ouml;st wurde.<br /><br />Autor: <i><a href="mailto:webmaster@yabbse.org">Das YaBB SE Team</a></i>.';

?>