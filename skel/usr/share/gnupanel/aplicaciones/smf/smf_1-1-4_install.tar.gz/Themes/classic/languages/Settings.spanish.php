<?php
// Version: 1.1; Settings

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'El tema cl&aacute;sico que introdujo al famos&iacute;simo proyecto de migraci&oacute; de YaBB a PHP/MySQL y lo distingui&oacute; a trav&eacute;s de dos a&ntilde;os de desarrollo, hasta su renacimiento como SMF.<br /><br />Autor: <i><a href="mailto:webmaster@yabbse.org">El equipo YaBB SE</a></i>.';

?>