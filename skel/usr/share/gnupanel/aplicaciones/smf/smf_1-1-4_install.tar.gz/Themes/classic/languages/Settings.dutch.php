<?php
// Version: 1.1; Settings

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'Het klassieke uiterlijk, dat gebruikt werd voor de revolutionaire PHP/MySQL overzetting van YaBB en dat onderscheidend is geweest tot de hergeboorte als SMF.<br /><br />Auteur: <i><a href="mailto:webmaster@yabbse.org">het YaBB SE Team</a></i>.';

?>